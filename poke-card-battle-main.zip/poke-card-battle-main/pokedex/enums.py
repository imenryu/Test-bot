from enum import StrEnum


class DataType(StrEnum):
    MOVE = "move"
    POKEMON = "pokemon"
    ENCOUNTER = "encounter"


class Region(StrEnum):
    KANTO = "kanto"
    JOHTO = "johto"
    HOENN = "hoenn"
    SINNOH = "sinnoh"
    UNOVA = "unova"
    KALOS = "kalos"
    ALOLA = "alola"
    GALAR = "galar"
    HISUI = "hisui"
    PALDEA = "paldea"


class Stat(StrEnum):
    HP = "health_points"
    ATTACK = "attack"
    DEFENSE = "defense"
    SPECIAL_ATTACK = "special_attack"
    SPECIAL_DEFENSE = "special_defense"
    SPEED = "speed"


class Type(StrEnum):
    NORMAL = "normal"
    FIGHTING = "fighting"
    FLYING = "flying"
    POISON = "poison"
    GROUND = "ground"
    ROCK = "rock"
    BUG = "bug"
    GHOST = "ghost"
    STEEL = "steel"
    FIRE = "fire"
    WATER = "water"
    GRASS = "grass"
    ELECTRIC = "electric"
    PSYCHIC = "psychic"
    ICE = "ice"
    DRAGON = "dragon"
    DARK = "dark"
    FAIRY = "fairy"
    STELLAR = "stellar"
    UNKNOWN = "unknown"
    SHADOW = "shadow"


class Nature(StrEnum):
    HARDY = "hardy"
    BOLD = "bold"
    MODEST = "modest"
    CALM = "calm"
    TIMID = "timid"
    LONELY = "lonely"
    DOCILE = "docile"
    MILD = "mild"
    GENTLE = "gentle"
    HASTY = "hasty"
    ADAMANT = "adamant"
    IMPISH = "impish"
    BASHFUL = "bashful"
    CAREFUL = "careful"
    RASH = "rash"
    JOLLY = "jolly"
    NAUGHTY = "naughty"
    LAX = "lax"
    QUIRKY = "quirky"
    NAIVE = "naive"
    BRAVE = "brave"
    RELAXED = "relaxed"
    QUIET = "quiet"
    SASSY = "sassy"
    SERIOUS = "serious"


class GrowthRate(StrEnum):
    SLOW = "slow"
    MEDIUM_SLOW = "medium-slow"
    MEDIUM = "medium"
    MEDIUM_FAST = "medium-fast"
    FAST = "fast"


class MoveLearnMethod(StrEnum):
    LEVEL_UP = "level-up"
    TUTOR = "tutor"
    MACHINE = "machine"


class MoveDamageClass(StrEnum):
    STATUS = "status"
    PHYSICAL = "physical"
    SPECIAL = "special"
