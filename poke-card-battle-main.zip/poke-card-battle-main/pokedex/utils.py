from __future__ import annotations

from typing import Dict, Final, List

from . import enums

STATS_TEMPLATE: Final[List[str]] = [s.value for s in list(enums.Stat)]

RegionDict: Final[Dict[str, "enums.Region"]] = {
    1: enums.Region.KANTO,
    2: enums.Region.JOHTO,
    3: enums.Region.HOENN,
    4: enums.Region.SINNOH,
    5: enums.Region.UNOVA,
    6: enums.Region.KALOS,
    7: enums.Region.ALOLA,
    8: enums.Region.GALAR,
    9: enums.Region.HISUI,
    10: enums.Region.PALDEA,
}

GrowthRateDict: Final[Dict[str, "enums.GrowthRate"]] = {
    1: enums.GrowthRate.SLOW,
    2: enums.GrowthRate.MEDIUM,
    3: enums.GrowthRate.MEDIUM_FAST,
    4: enums.GrowthRate.MEDIUM_SLOW,
    5: enums.GrowthRate.FAST,
    6: enums.GrowthRate.SLOW,
}

NatureDict: Final[Dict[int, "enums.Nature"]] = {
    1: enums.Nature.HARDY,
    2: enums.Nature.BOLD,
    3: enums.Nature.MODEST,
    4: enums.Nature.CALM,
    5: enums.Nature.TIMID,
    6: enums.Nature.LONELY,
    7: enums.Nature.DOCILE,
    8: enums.Nature.MILD,
    9: enums.Nature.GENTLE,
    10: enums.Nature.HASTY,
    11: enums.Nature.ADAMANT,
    12: enums.Nature.IMPISH,
    13: enums.Nature.BASHFUL,
    14: enums.Nature.CAREFUL,
    15: enums.Nature.RASH,
    16: enums.Nature.JOLLY,
    17: enums.Nature.NAUGHTY,
    18: enums.Nature.LAX,
    19: enums.Nature.QUIRKY,
    20: enums.Nature.NAIVE,
    21: enums.Nature.BRAVE,
    22: enums.Nature.RELAXED,
    23: enums.Nature.QUIET,
    24: enums.Nature.SASSY,
    25: enums.Nature.SERIOUS,
}

TypeDict: Final[Dict[str, "enums.Type"]] = {
    1: enums.Type.NORMAL,
    2: enums.Type.FIGHTING,
    3: enums.Type.FLYING,
    4: enums.Type.POISON,
    5: enums.Type.GROUND,
    6: enums.Type.ROCK,
    7: enums.Type.BUG,
    8: enums.Type.GHOST,
    9: enums.Type.STEEL,
    10: enums.Type.FIRE,
    11: enums.Type.WATER,
    12: enums.Type.GRASS,
    13: enums.Type.ELECTRIC,
    14: enums.Type.PSYCHIC,
    15: enums.Type.ICE,
    16: enums.Type.DRAGON,
    17: enums.Type.DARK,
    18: enums.Type.FAIRY,
    19: enums.Type.STELLAR,
    10001: enums.Type.UNKNOWN,
    10002: enums.Type.SHADOW,
}

MoveLearnMethodDict: Final[Dict[str, "enums.MoveLearnMethod"]] = {
    1: enums.MoveLearnMethod.LEVEL_UP,
    3: enums.MoveLearnMethod.TUTOR,
    4: enums.MoveLearnMethod.MACHINE,
}

MoveDamageClassDict: Final[Dict[str, "enums.MoveDamageClass"]] = {
    1: enums.MoveDamageClass.STATUS,
    2: enums.MoveDamageClass.PHYSICAL,
    3: enums.MoveDamageClass.SPECIAL,
}
