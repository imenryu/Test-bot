from .pokedexbase import PokedexBase

pokedex = PokedexBase()

__all__ = ("pokedex",)
