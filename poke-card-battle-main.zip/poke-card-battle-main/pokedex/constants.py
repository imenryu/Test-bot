from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Final, List


@dataclass(frozen=True, slots=True)
class _CONSTANTS:
    POKEDEX_ROOT_PATH: "Path" = Path(__file__).parent
    XDG_RAWDATA_HOME: str = f"{POKEDEX_ROOT_PATH}/rawdata"

    MAX_IV_PER_STAT: int = 31
    MIN_IV_PER_STAT: int = 1
    MAX_IV_TOTAL: int = 186
    MIN_IV_TOTAL: int = 1

    MAX_EV_PER_STAT: int = 252
    MIN_EV_PER_STAT: int = 1
    MAX_EV_TOTAL: int = 510
    MIN_EV_TOTAL: int = 1

    MAX_NATURE_ID: int = 25
    MIN_NATURE_ID: int = 1

    DEFAULT_LOCATION: str = "VIRIDIAN FOREST"

    DEFAULT_STARTER_LEVEL: int = 5
    STARTER_POKEMON: List[Dict[str, int | str]] = field(
        default_factory=lambda: [
            {
                "id": 147,
                "name": "Dratini",
            },
            {
                "id": 246,
                "name": "Larvitar",
            },
            {
                "id": 371,
                "name": "Bagon",
            },
            {
                "id": 374,
                "name": "Beldum",
            },
            {
                "id": 443,
                "name": "Gible",
            },
            {
                "id": 633,
                "name": "Deino",
            },
            {
                "id": 704,
                "name": "Goomy",
            },
            {
                "id": 782,
                "name": "Jangmo-o",
            },
            {
                "id": 885,
                "name": "Dreepy",
            },
            {
                "id": 996,
                "name": "Frigibax",
            },
        ]
    )


CONSTANTS: Final["_CONSTANTS"] = _CONSTANTS()
