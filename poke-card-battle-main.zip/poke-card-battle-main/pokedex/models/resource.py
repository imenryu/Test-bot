from dataclasses import dataclass


class MetaResource(type):
    def __new__(cls, name, bases, clsdict):
        return dataclass(eq=True, unsafe_hash=True)(
            super().__new__(
                cls,
                name,
                bases,
                clsdict,
            )
        )


class Resource(metaclass=MetaResource):
    """Base resource with an id and name"""

    id: int
    name: str

    __slots__ = ("id", "name")

    def __setattr__(self, key, value):
        """Lock attributes after initialization"""
        if hasattr(self, key):
            raise AttributeError(
                f"{self.__class__.__name__} is immutable: cannot reassign {key!r}"
            )
        super().__setattr__(key, value)
