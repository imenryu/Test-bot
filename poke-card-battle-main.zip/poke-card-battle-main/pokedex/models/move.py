from . import utils
from .resource import Resource


class Move(Resource):
    __slots__ = (
        "id",
        "name",
        "power",
        "accuracy",
        "crit_rate",
        "type",
        "damage_class",
    )

    def __init__(
        self,
        id: int,
        name: str,
        power: int,
        accuracy: int,
        crit_rate: int,
        move_type: int,
        damage_class: int,
    ) -> None:
        super().__init__(id=id, name=name)
        self.power = power
        self.accuracy = accuracy
        self.crit_rate = crit_rate
        self.type = utils.get_type(move_type)
        self.damage_class = utils.get_damage_class(damage_class)

    def __repr__(self):
        slots = ", ".join(
            f"{slot}={getattr(self, slot)!r}" for slot in self.__slots__)
        return f"{self.__class__.__name__}({slots})"
