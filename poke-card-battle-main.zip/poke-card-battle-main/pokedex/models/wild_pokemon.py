from __future__ import annotations

from typing import TYPE_CHECKING

from .resource import Resource

if TYPE_CHECKING:
    from pokedex.enums import Nature


class WildPokemon(Resource):
    __slots__ = (
        "id",
        "name",
        "level",
        "moveset",
        "nature",
        "ivs",
        "evs",
        "shiny",
        "region",
        "location",
        "base_chance",
        "effective_chance",
    )

    def __init__(
        self,
        id: int,
        name: str,
        level: int,
        moveset: list[int],
        nature: Nature,
        ivs: dict,
        evs: dict,
        shiny: bool,
        region: str,
        location: str,
        base_chance: int,
        effective_chance: int,
    ) -> None:
        super().__init__(id=id, name=name)
        self.level = level
        self.moveset = moveset
        self.nature = nature
        self.ivs = ivs
        self.evs = evs
        self.shiny = shiny
        self.region = region
        self.location = location
        self.base_chance = base_chance
        self.effective_chance = effective_chance

    def __repr__(self):
        slots = ", ".join(
            f"{slot}={getattr(self, slot)!r}" for slot in self.__slots__)
        return f"{self.__class__.__name__}({slots})"
