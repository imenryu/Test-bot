from __future__ import annotations

import random
from typing import Dict, Final, Optional, Sequence, Tuple

from pokedex import enums
from pokedex.constants import CONSTANTS
from pokedex.errors import ErrorContext, IVGenerationError
from pokedex.utils import STATS_TEMPLATE

# ---------------- Type Aliases ----------------
StatDict = Dict[str, int]
StatTuple = Tuple[str, int]
MinThresholds = Sequence[Tuple[int, int]]
LockedValues = Dict[enums.Stat | str, int | Tuple[int, int]]


# ==================== Base PokemonStats ====================
class PokemonStats:
    """
    Represents a Pokémon's six core stats with dict-like access,
    comparison, and arithmetic support.

    Attributes
    ----------
    health_points : int
        The HP stat.
    attack : int
        The Attack stat.
    defense : int
        The Defense stat.
    special_attack : int
        The Special Attack stat.
    special_defense : int
        The Special Defense stat.
    speed : int
        The Speed stat.

    Examples
    --------
    >>> stats = PokemonStats.from_dict({"health_points": 50, "attack": 60, "defense": 45, "special_attack": 70, "special_defense": 55, "speed": 65})
    >>> stats.total
    345
    >>> stats["attack"]
    60
    >>> stats.max_stat()
    ('special_attack', 70)
    """

    __slots__ = tuple(STATS_TEMPLATE)

    def __init__(
        self,
        health_points: int,
        attack: int,
        defense: int,
        special_attack: int,
        special_defense: int,
        speed: int,
    ) -> None:
        self.health_points = int(health_points)
        self.attack = int(attack)
        self.defense = int(defense)
        self.special_attack = int(special_attack)
        self.special_defense = int(special_defense)
        self.speed = int(speed)

    # ---- Properties ----
    @property
    def total(self) -> int:
        """Sum of all six stats."""
        return sum(getattr(self, s) for s in self.__slots__)

    def to_dict(self) -> StatDict:
        """Convert stats to {stat_name: value} dict."""
        return {s: getattr(self, s) for s in self.__slots__}

    def max_stat(self) -> StatTuple:
        """Return the stat with the highest value."""
        return max(self.to_dict().items(), key=lambda x: x[1])

    def min_stat(self) -> StatTuple:
        """Return the stat with the lowest value."""
        return min(self.to_dict().items(), key=lambda x: x[1])

    # ---- Iteration ----
    def items(self):
        return self.to_dict().items()

    def values(self):
        return self.to_dict().values()

    def keys(self):
        return self.to_dict().keys()

    # ---- Index-like Access ----
    def __getitem__(self, stat: str | enums.Stat) -> int:
        key = stat.value if isinstance(stat, enums.Stat) else stat
        return getattr(self, key)

    def __setitem__(self, stat: str | enums.Stat, value: int) -> None:
        key = stat.value if isinstance(stat, enums.Stat) else stat
        setattr(self, key, int(value))

    # ---- Comparisons & Arithmetic ----
    def __eq__(self, other):
        return isinstance(other, PokemonStats) and self.to_dict() == other.to_dict()

    def __add__(self, other: "PokemonStats") -> "PokemonStats":
        return self.__class__(
            **{s: getattr(self, s) + getattr(other, s) for s in self.__slots__}
        )

    def __sub__(self, other: "PokemonStats") -> "PokemonStats":
        return self.__class__(
            **{s: getattr(self, s) - getattr(other, s) for s in self.__slots__}
        )

    def __lt__(self, other: "PokemonStats") -> bool:
        return self.total < other.total

    def __gt__(self, other: "PokemonStats") -> bool:
        return self.total > other.total

    # ---- Representations ----
    def __repr__(self) -> str:
        stats = ", ".join(
            f"{s}={getattr(self, s)!r}" for s in (self.__slots__ + ("total",))
        )
        return f"{self.__class__.__name__}({stats})"

    def __str__(self) -> str:
        return self.__repr__()


# ==================== BaseStats ====================
class BaseStats(PokemonStats):
    """
    Species base stats from the Pokédex.

    Base stats define a Pokémon's innate potential before IVs,
    EVs, levels, or nature.
    """

    __slots__ = tuple(STATS_TEMPLATE)

    def __init__(
        self,
        health_points: int,
        attack: int,
        defense: int,
        special_attack: int,
        special_defense: int,
        speed: int,
    ) -> None:
        super().__init__(
            health_points,
            attack,
            defense,
            special_attack,
            special_defense,
            speed,
        )

    # ---- Alternate Constructors ----
    @classmethod
    def from_dict(cls, data: StatDict) -> "BaseStats":
        """Convert stats from a dictionary with string keys."""
        return cls(**data)

    def copy(self) -> "BaseStats":
        return self.from_dict(self.to_dict())


# ==================== IVs (Individual Values) ====================
class IVs(PokemonStats):
    """
    Individual Values (IVs) for a Pokémon.

    IVs are hidden values that affect a Pokémon’s potential
    for each stat. Range: 0–31 per stat, 0–186 total.
    """

    __slots__ = tuple(STATS_TEMPLATE)
    MAX_ATTEMPTS: Final[int] = 5000

    def __init__(
        self,
        health_points: int,
        attack: int,
        defense: int,
        special_attack: int,
        special_defense: int,
        speed: int,
    ) -> None:
        super().__init__(
            health_points,
            attack,
            defense,
            special_attack,
            special_defense,
            speed,
        )

    # ---- Alternate Constructors ----
    @classmethod
    def from_dict(cls, data: StatDict) -> "IVs":
        """Convert stats from a dictionary with string keys."""
        return cls(**data)

    def copy(self) -> "IVs":
        return self.from_dict(self.to_dict())

    @classmethod
    def generate(
        cls,
        min_thresholds: Optional[MinThresholds] = None,
        locked_values: Optional[LockedValues] = None,
        min_total: int = CONSTANTS.MIN_IV_TOTAL,
        max_total: int = CONSTANTS.MAX_IV_TOTAL,
        raw: bool = False,
    ) -> "IVs":
        """
        Generate a new set of Pokémon IVs (Individual Values).

        Parameters
        ----------
        min_thresholds : list[tuple[int, int]], optional
            Rules like ``[(min_value, count), ...]``.
            Each rule means at least ``count`` distinct stats must have IVs
            in the range [min_value, 31].

        locked_values : dict[Stat, int | tuple[int, int]], optional
            Lock specific stats to exact or ranged values.
            Example: ``{enums.Stat.ATTACK: 31, enums.Stat.SPEED: (20, 25)}``

        min_total : int, default=1
            Minimum allowed sum of all IVs (1–186).

        max_total : int, default=186
            Maximum allowed sum of all IVs (1–186).

        Returns
        -------
        IVs
            An ``IVs`` object with generated values.

        Notes
        -----
        - ``min_thresholds`` and ``locked_values`` cannot overlap.
        - Unspecified stats are filled with random values [0, 31].
        - Retries until total IV sum is between ``min_total`` and ``max_total``,
          or fails after ``MAX_ATTEMPTS``.
        """
        min_thresholds = min_thresholds or []
        locked_values = locked_values or {}

        stats = STATS_TEMPLATE
        locked_values_str: Dict[str, int | Tuple[int, int]] = {}

        # --- Validate and convert locked_values ---
        for stat_key, val in locked_values.items():
            stat = stat_key.value if isinstance(
                stat_key, enums.Stat) else stat_key
            if stat not in stats:
                raise IVGenerationError(
                    message=f"Invalid stat '{stat}' in locked_values.",
                    context=ErrorContext(details={"stat": stat}),
                    user_friendly_message=f"The stat '{stat}' is not a valid Pokémon stat.",
                )
            if isinstance(val, int):
                if not (CONSTANTS.MIN_IV_PER_STAT <= val <= CONSTANTS.MAX_IV_PER_STAT):
                    raise IVGenerationError(
                        message=f"Locked value for {stat} is out of range.",
                        context=ErrorContext(
                            details={"stat": stat, "value": val}),
                        user_friendly_message=(
                            f"The locked IV value for {stat} must be between "
                            f"{CONSTANTS.MIN_IV_PER_STAT} and {CONSTANTS.MAX_IV_PER_STAT}."
                        ),
                    )
            elif isinstance(val, tuple) and len(val) == 2:
                lo, hi = val
                if not (
                    CONSTANTS.MIN_IV_PER_STAT <= lo <= hi <= CONSTANTS.MAX_IV_PER_STAT
                ):
                    raise IVGenerationError(
                        message=f"Locked range for {stat} is invalid.",
                        context=ErrorContext(
                            details={"stat": stat, "range": val}),
                        user_friendly_message=(
                            f"The locked IV range for {stat} must be between "
                            f"{CONSTANTS.MIN_IV_PER_STAT} and {CONSTANTS.MAX_IV_PER_STAT}, "
                            "with the first value less than or equal to the second."
                        ),
                    )
            else:
                raise IVGenerationError(
                    message=f"Invalid locked value format for {stat}.",
                    context=ErrorContext(
                        details={"stat": stat, "value": val,
                                 "type": type(val).__name__}
                    ),
                    user_friendly_message=f"The locked IV value for {stat} must be an integer or a tuple of two integers.",
                )
            locked_values_str[stat] = val

        for attempt in range(cls.MAX_ATTEMPTS):
            ivs: Dict[str, Optional[int]] = {s: None for s in stats}
            assigned = set()

            # --- Apply min_thresholds ---
            available = [s for s in stats if s not in locked_values_str]
            for min_val, count in min_thresholds:
                if not (0 <= min_val <= CONSTANTS.MAX_IV_PER_STAT):
                    raise IVGenerationError(
                        message=f"Minimum threshold value {min_val} is out of range.",
                        context=ErrorContext(
                            details={"min_val": min_val, "count": count}
                        ),
                        user_friendly_message=(
                            "The minimum IV threshold must be between "
                            f"{CONSTANTS.MIN_IV_PER_STAT} and {CONSTANTS.MAX_IV_PER_STAT}."
                        ),
                    )
                if count > len(available):
                    raise IVGenerationError(
                        message="Not enough unassigned stats for `min_thresholds` rule.",
                        context=ErrorContext(
                            details={
                                "count_needed": count,
                                "stats_available": len(available),
                            }
                        ),
                        user_friendly_message="There are not enough stats left to satisfy the minimum threshold rule.",
                    )
                chosen = random.sample(available, count)
                for s in chosen:
                    ivs[s] = random.randint(min_val, CONSTANTS.MAX_IV_PER_STAT)
                    assigned.add(s)
                    available.remove(s)

            # --- Apply locked_values ---
            for s, val in locked_values_str.items():
                if s in assigned:
                    raise IVGenerationError(
                        message=f"Conflicting constraints: {s} is in both `min_thresholds` and `locked_values`.",
                        context=ErrorContext(
                            details={
                                "stat": s,
                                "conflicting_rules": [
                                    "min_thresholds",
                                    "locked_values",
                                ],
                            }
                        ),
                        user_friendly_message=(
                            f"The stat '{s}' cannot be specified in both 'min_thresholds' and 'locked_values'. "
                            "Please remove the conflicting stat from one of the rules."
                        ),
                    )
                if isinstance(val, int):
                    ivs[s] = val
                else:
                    lo, hi = val
                    ivs[s] = random.randint(lo, hi)
                assigned.add(s)

            # --- Fill remaining stats randomly ---
            for s in stats:
                if ivs[s] is None:
                    ivs[s] = random.randint(
                        CONSTANTS.MIN_IV_PER_STAT,
                        CONSTANTS.MAX_IV_PER_STAT,
                    )

            # --- Check total sum ---
            total = sum(v for v in ivs.values() if v is not None)
            if min_total <= total <= max_total:
                if raw:
                    return {s: ivs[s] for s in stats}
                return cls.from_dict({s: ivs[s] for s in stats})

        raise IVGenerationError(
            message=f"Failed to generate IVs within constraints after {cls.MAX_ATTEMPTS} attempts.",
            context=ErrorContext(
                details={
                    "min_thresholds": min_thresholds,
                    "locked_values": locked_values,
                    "min_total": min_total,
                    "max_total": max_total,
                    "attempts": cls.MAX_ATTEMPTS,
                }
            ),
            user_friendly_message=(
                "Could not find a valid combination of IVs that meets all of your requirements. "
                "Please try again with looser constraints."
            ),
        )

    @property
    def average_percentage(self) -> float:
        """Average percentage filled per stat (0.0–1.0)."""
        return sum(
            getattr(self, s) / CONSTANTS.MAX_IV_PER_STAT for s in STATS_TEMPLATE
        ) / len(STATS_TEMPLATE)

    @property
    def overall_percentage(self) -> float:
        """Overall percentage of total IVs relative to the maximum (0.0–1.0)."""
        return self.total / CONSTANTS.MAX_IV_TOTAL


# ==================== EVs (Effort Values) ====================
class EVs(PokemonStats):
    """
    Effort Values (EVs) for a Pokémon.

    EVs are earned through battles and training. They influence
    stat growth. Max: 252 per stat, 510 total.
    """

    __slots__ = tuple(STATS_TEMPLATE)

    def __init__(
        self,
        health_points: int,
        attack: int,
        defense: int,
        special_attack: int,
        special_defense: int,
        speed: int,
    ) -> None:
        super().__init__(
            health_points,
            attack,
            defense,
            special_attack,
            special_defense,
            speed,
        )

    # ---- Alternate Constructors ----
    @classmethod
    def from_dict(cls, data: StatDict) -> "EVs":
        """Convert stats from a dictionary with string keys."""
        return cls(**data)

    def copy(self) -> "EVs":
        return self.from_dict(self.to_dict())

    @classmethod
    def default(cls) -> "EVs":
        """Return EVs initialized to zero for all stats."""
        return cls.from_dict({s: 0 for s in STATS_TEMPLATE})

    @property
    def average_percentage(self) -> float:
        """Average percentage filled per stat (0.0–1.0)."""
        return sum(
            getattr(self, s) / CONSTANTS.MAX_EV_PER_STAT for s in STATS_TEMPLATE
        ) / len(STATS_TEMPLATE)

    @property
    def overall_percentage(self) -> float:
        """Overall percentage of total EVs relative to the maximum (0.0–1.0)."""
        return self.total / CONSTANTS.MAX_EV_TOTAL
