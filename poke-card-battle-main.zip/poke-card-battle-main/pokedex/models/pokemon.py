from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from pokedex.errors import LearnableMoveError

from . import utils
from .resource import Resource
from .stats import BaseStats

if TYPE_CHECKING:
    from pokedex.enums import MoveLearnMethod


class PokemonSprites:
    __slots__ = ("front_default", "front_shiny")

    def __init__(
        self,
        front_default: str,
        front_shiny: str,
    ) -> None:
        self.front_default = front_default
        self.front_shiny = front_shiny

    def __repr__(self):
        slots = ", ".join(
            f"{slot}={getattr(self, slot)!r}" for slot in self.__slots__)
        return f"{self.__class__.__name__}({slots})"


class PokemonEvolvesTo(Resource):
    __slots__ = ("id", "name", "min_level")

    def __init__(self, id: int, name: str, min_level: int) -> None:
        super().__init__(id=id, name=name)
        self.min_level = min_level

    def __repr__(self):
        slots = ", ".join(
            f"{slot}={getattr(self, slot)!r}" for slot in self.__slots__)
        return f"{self.__class__.__name__}({slots})"


class PokemonLearnableMoves(Resource):
    __slots__ = ("id", "name", "min_level", "learn_method")

    def __init__(self, id: int, name: str, min_level: int, learn_method: int) -> None:
        super().__init__(id=id, name=name)
        self.min_level = min_level
        self.learn_method = utils.get_move_learn_method(learn_method)

    def __repr__(self):
        slots = ", ".join(
            f"{slot}={getattr(self, slot)!r}" for slot in self.__slots__)
        return f"{self.__class__.__name__}({slots})"


class Pokemon(Resource):
    __slots__ = (
        "id",
        "name",
        "is_legendary",
        "is_mythical",
        "capture_rate",
        "growth_rate",
        "evolves_from",
        "evolves_to",
        "base_stats",
        "ev_yields",
        "learnable_moves",
        "sprites",
        "types",
    )

    def __init__(
        self,
        id: int,
        name: str,
        is_legendary: bool,
        is_mythical: bool,
        capture_rate: int,
        growth_rate: int,
        evolves_from: Optional[int],
        evolves_to: Optional[Dict[str, Any]],
        base_stats: Dict[str, int],
        ev_yields: Dict[str, int],
        learnable_moves: List[Dict[str, Any]],
        sprites: Dict[str, str],
        types: List[str],
    ) -> None:
        super().__init__(id=id, name=name)
        self.is_legendary = is_legendary
        self.is_mythical = is_mythical
        self.capture_rate = capture_rate
        self.growth_rate = utils.get_growth_rate(growth_rate)
        self.evolves_from = evolves_from
        self.evolves_to = PokemonEvolvesTo(
            **evolves_to) if evolves_to else None
        self.base_stats = BaseStats(**base_stats)
        self.ev_yields = ev_yields
        self.learnable_moves = [PokemonLearnableMoves(
            **lm) for lm in learnable_moves]
        self.sprites = PokemonSprites(**sprites)
        self.types = [utils.get_type(t) for t in types]

    def __repr__(self):
        slots = ", ".join(
            f"{slot}={getattr(self, slot)!r}" for slot in self.__slots__)
        return f"{self.__class__.__name__}({slots})"

    def get_move_by_learn_method(
        self,
        learn_method: MoveLearnMethod | int,
        min_level: int = 0,
        max_level: int = 100,
    ) -> List[PokemonLearnableMoves]:
        if not (0 <= min_level <= max_level <= 100):
            raise LearnableMoveError(
                message="Invalid level range provided.",
                context={
                    "min_level": min_level,
                    "max_level": max_level,
                    "learn_method": learn_method,
                },
                user_friendly_message="The levels must be between 0 and 100, with the minimum level being less than or equal to the maximum level.",
            )
        if isinstance(learn_method, int):
            learn_method = utils.get_move_learn_method(learn_method)
        return [
            move
            for move in self.learnable_moves
            if move.learn_method == learn_method
            and min_level <= move.min_level <= max_level
        ]
