from __future__ import annotations

from typing import TYPE_CHECKING

from .. import utils as ut

if TYPE_CHECKING:
    from pokedex import enums


def get_type(t: int) -> enums.Type:
    return ut.TypeDict.get(t)


def get_damage_class(damage_class: int) -> enums.MoveDamageClass:
    return ut.MoveDamageClassDict.get(damage_class)


def get_move_learn_method(learn_method: int) -> enums.MoveLearnMethod:
    return ut.MoveLearnMethodDict.get(learn_method)


def get_growth_rate(growth_rate: int) -> enums.GrowthRate:
    return ut.GrowthRateDict.get(growth_rate)
