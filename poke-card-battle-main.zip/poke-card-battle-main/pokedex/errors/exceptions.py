from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Optional, Union

from .base import PokedexError

if TYPE_CHECKING:
    from .base import ErrorContext


class UnknownError(PokedexError):
    """
    Raised for unknown error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69069,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class DataError(PokedexError):
    """
    Raised for data error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69001,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class MoveError(DataError):
    """
    Raised for move error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69002,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class PokemonError(DataError):
    """
    Raised for pokémon error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69003,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class StatsError(PokemonError):
    """
    Raised for pokémon stats error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69004,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class DataTypeError(DataError):
    """
    Raised for datatype error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69005,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class InvalidMoveID(MoveError):
    """
    Raised for move error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69006,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class InvalidPokemonID(PokemonError):
    """
    Raised for invalid pokémon id error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69007,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class InvalidPokemonName(PokemonError):
    """
    Raised for invalid pokémon name error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69008,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class LearnableMoveError(PokemonError):
    """
    Raised for learnable pokémon move error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69009,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class InvalidStarterPokemon(PokemonError):
    """
    Raised for invalid pokémon id error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69010,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class PokemonSpawnError(PokemonError):
    """
    Raised when pokémon spawn error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69011,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class InvalidStat(StatsError):
    """
    Raised when invalid stat.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69012,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class IVGenerationError(StatsError):
    """
    Raised when iv generation failed.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69013,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )
