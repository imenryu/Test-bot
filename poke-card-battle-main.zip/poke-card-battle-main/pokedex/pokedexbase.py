from __future__ import annotations

import difflib
import json
import os
import secrets
from typing import Dict, List, Optional, Tuple

import aiofiles
from cachetools import LRUCache, cached
from loguru import logger

from . import enums
from .constants import CONSTANTS
from .errors import (
    DataError,
    DataTypeError,
    ErrorContext,
    InvalidMoveID,
    InvalidPokemonID,
    InvalidPokemonName,
    InvalidStarterPokemon,
    PokemonSpawnError,
)
from .models import Move, Pokemon, WildPokemon
from .models.stats import EVs, IVs


class PokedexBase:
    __slots__ = (
        "data",
        "_valid_move_ids",
        "_valid_pokemon_ids",
        "_valid_pokemon_names",
        "_valid_locations",
    )

    def __init__(self) -> None:
        self.data: Dict[str, Dict[str, int | str]] = {}
        self._valid_move_ids: List[int] = []
        self._valid_pokemon_ids: List[int] = []
        self._valid_pokemon_names: List[str] = []
        self._valid_locations: Dict[str, List[str]] = {}

    async def initialize(self) -> None:
        for filename in os.listdir(CONSTANTS.XDG_RAWDATA_HOME):
            if filename.endswith(".json"):
                filepath = os.path.join(CONSTANTS.XDG_RAWDATA_HOME, filename)
                try:
                    async with aiofiles.open(filepath, mode="r", encoding="utf8") as f:
                        contents = await f.read()
                        data = json.loads(contents)

                        key = filename[:-5]
                        self.data[key] = data

                        if key == enums.DataType.MOVE.value:
                            self._valid_move_ids.extend(
                                metadata["id"] for metadata in data.values()
                            )
                        elif key == enums.DataType.POKEMON.value:
                            self._valid_pokemon_ids.extend(
                                metadata["id"] for metadata in data.values()
                            )
                            self._valid_pokemon_names.extend(
                                metadata["name"] for metadata in data.values()
                            )
                        elif key == enums.DataType.ENCOUNTER.value:
                            location_dict: Dict[str, List[str]] = {}
                            for region, location_data in data.items():
                                location_dict[region] = list(
                                    location_data.keys())

                            self._valid_locations.update(location_dict)
                except (OSError, json.JSONDecodeError):
                    logger.exception(
                        f"[{self.__class__.__name__}] Error opening or reading pokedex rawdata file: {filename}:{filepath}"
                    )

        logger.debug(
            f"{self.__class__.__name__} Initialized "
            f"(Pokémon: {len(self._valid_pokemon_ids)}, Moves: {len(self._valid_move_ids)})"
        )

    async def shutdown(self) -> None:
        self.data.clear()
        self._valid_move_ids.clear()
        self._valid_pokemon_ids.clear()
        self._valid_pokemon_names.clear()
        self._valid_locations.clear()
        if hasattr(self._get_item, "cache_clear"):
            self._get_item.cache_clear()
        logger.debug(f"{self.__class__.__name__} Shutdown")

    @property
    def valid_move_ids(self) -> List[int]:
        return self._valid_move_ids

    @property
    def valid_pokemon_ids(self) -> List[int]:
        return self._valid_pokemon_ids

    @property
    def valid_pokemon_names(self) -> List[str]:
        return self._valid_pokemon_names

    @property
    def valid_locations(self) -> Dict[str, List[str]]:
        return self._valid_locations

    def _id_validation(self, id: int, data_type: enums.DataType) -> None:
        if data_type == enums.DataType.MOVE:
            if id not in self.valid_move_ids:
                raise InvalidMoveID(
                    message=f"Invalid move ID: {id}.",
                    context=ErrorContext(
                        details={"id": id, "valid_ids_count": len(
                            self.valid_move_ids)}
                    ),
                    user_friendly_message=f"The move ID '{id}' doesn't exist.",
                )

        elif data_type == enums.DataType.POKEMON:
            if id not in self.valid_pokemon_ids:
                raise InvalidPokemonID(
                    message=f"Invalid Pokémon ID: {id}.",
                    context=ErrorContext(
                        details={
                            "id": id,
                            "valid_ids_count": len(self.valid_pokemon_ids),
                        }
                    ),
                    user_friendly_message=f"The Pokémon ID '{id}' doesn't exist.",
                )
        else:
            raise DataTypeError(
                message=f"Invalid data_type for ID validation: {data_type.name.lower()}.",
                context=ErrorContext(
                    details={
                        "data_type": data_type,
                        "expected": (enums.DataType.MOVE, enums.Datatype.POKEMON),
                    }
                ),
                user_friendly_message="An internal error occurred while validating data.",
            )

    def _find_similar(self, name: str) -> List["Pokemon"]:
        results: List["Pokemon"] = []
        matches = difflib.get_close_matches(
            word=name,
            possibilities=self.valid_pokemon_names,
        )
        if matches:
            for match in matches:
                item = self.get_pokemon(match)
                if item and isinstance(item, Pokemon):
                    results.append(item)
        if results and len(results) > 0:
            return results
        raise InvalidPokemonName(
            message=f"Invalid Pokémon Name: {id}.",
            context=ErrorContext(
                details={
                    "name": name,
                    "valid_names_count": len(self.valid_pokemon_names),
                }
            ),
            user_friendly_message=f"The Pokémon Name '{name}' doesn't exist.",
        )

    @staticmethod
    def _weighted_choice(
        options: List[Dict[str, int | str]],
        multipliers: Optional[Dict[str, float]] = None,
    ):
        weights: List[int, float] = []
        for poke in options:
            base_chance = poke["chance"]
            mult = multipliers.get(
                poke["name"].lower(), 1.0) if multipliers else 1.0
            weights.append(base_chance * mult)

        total = int(sum(weights))
        if total <= 0:
            raise PokemonSpawnError(
                message="Weighted choice failed: total calculated weight was zero or less.",
                context=ErrorContext(
                    details={
                        "options": options,
                        "multipliers": multipliers,
                        "calculated_total": total,
                    }
                ),
                user_friendly_message="A Pokémon could not be selected from the available options.",
            )
        r = secrets.randbelow(total)
        cumulative = 0
        for poke, w in zip(options, weights):
            cumulative += w
            if r < cumulative:
                return poke, w
        return options[-1], weights[-1]

    @cached(cache=LRUCache(maxsize=1024))
    def _get_item(
        self,
        id_or_name: int | str,
        data_type: enums.DataType,
        model_class: "Pokemon" | "Move",
    ) -> Optional["Pokemon" | "Move" | List["Pokemon"]]:
        try:
            data: Dict[str, int | str] = self.data[data_type.value]
        except KeyError as ke:
            raise DataError(
                message=f"Data type '{data_type.value}' not found in loaded data.",
                context=ErrorContext(
                    details={
                        "missing_key": data_type.value,
                        "original_error": str(ke),
                    }
                ),
                user_friendly_message="Could not find the requested data. The Pokédex might be incomplete.",
            )

        if isinstance(id_or_name, int):
            self._id_validation(id_or_name, data_type)
            item = data.get(str(id_or_name))
            return model_class(**item)
        elif isinstance(id_or_name, str):
            if id_or_name.isdigit():
                self._id_validation(int(id_or_name), data_type)
                item = data.get(id_or_name)
                return model_class(**item)
            else:
                name = id_or_name.strip().lower().replace(" ", "-")
                for _, item in data.items():
                    if item["name"] == name:
                        return model_class(**item)
                if data_type == enums.DataType.POKEMON:
                    return self._find_similar(name=name)
        else:
            raise DataTypeError(
                message=f"Invalid type for id_or_name: {type(id_or_name).__name__}.",
                context=ErrorContext(
                    details={
                        "id_or_name": id_or_name,
                        "type": type(id_or_name).__name__,
                        "expected": (str, int),
                    }
                ),
                user_friendly_message="You must search for a Pokémon or move using its name (text) or ID (number).",
            )

    def get_all_moves(self) -> List["Move"]:
        try:
            _data_type = enums.DataType.MOVE
            data: Dict[str, int | str] = self.data[_data_type.value]
            return [Move(**move) for move in data.values()]
        except KeyError as ke:
            raise DataError(
                message="The 'move' data key was not found in the loaded Pokédex data.",
                context=ErrorContext(
                    details={
                        "missing_key": _data_type.value,
                        "original_error": str(ke),
                    }
                ),
                user_friendly_message="Could not retrieve the list of moves.",
            )

    def get_move(self, id_or_name: int | str) -> Optional["Move"]:
        return self._get_item(id_or_name, enums.DataType.MOVE, Move)

    def get_all_pokemon(self) -> List["Pokemon"]:
        try:
            _data_type = enums.DataType.POKEMON
            data: Dict[str, int | str] = self.data[_data_type.value]
            return [Pokemon(**pokemon) for pokemon in data.values()]
        except KeyError as ke:
            raise DataError(
                message="The 'pokemon' data key was not found in the loaded Pokédex data.",
                context=ErrorContext(
                    details={
                        "missing_key": _data_type.value,
                        "original_error": str(ke),
                    }
                ),
                user_friendly_message="Could not retrieve the list of Pokémon.",
            )

    def get_pokemon(
        self, id_or_name: int | str
    ) -> Optional["Pokemon" | List["Pokemon"]]:
        return self._get_item(id_or_name, enums.DataType.POKEMON, Pokemon)

    def get_starter(
        self,
        id_or_name: int | str,
        min_level: Optional[int] = None,
        max_level: Optional[int] = None,
    ) -> "WildPokemon":
        starter: dict[str, int | str] = None
        for pokemon in CONSTANTS.STARTER_POKEMON:
            if isinstance(id_or_name, int):
                if pokemon["id"] == id_or_name:
                    starter = pokemon
                    break
            elif isinstance(id_or_name, str):
                if id_or_name.isdigit() and pokemon["id"] == int(id_or_name):
                    starter = pokemon
                    break
                elif pokemon["name"].lower() == id_or_name.lower():
                    starter = pokemon
                    break

        if starter is None:
            raise InvalidStarterPokemon(
                message=f"'{id_or_name}' is not a valid starter Pokémon.",
                context=ErrorContext(
                    details={
                        "id_or_name": id_or_name,
                        "valid_starters": [
                            (p["id"] if isinstance(id_or_name, int) else p["name"])
                            for p in CONSTANTS.STARTER_POKEMON
                        ],
                    }
                ),
                user_friendly_message=f"You can't choose '{id_or_name}' as your starter. Please pick a valid one.",
            )

        if min_level and max_level:
            if any(lvl <= 0 for lvl in (min_level, max_level)):
                raise InvalidStarterPokemon(
                    message="Invalid level arguments: min_level or max_level must be a positive number.",
                    context=ErrorContext(
                        details={
                            "min_level": min_level,
                            "max_level": max_level,
                        }
                    ),
                    user_friendly_message="Starter level must be a positive number.",
                )
            level = secrets.randbelow(max_level - min_level + 1) + min_level
        else:
            level = CONSTANTS.DEFAULT_STARTER_LEVEL

        pokemon = self.get_pokemon(id_or_name=starter["id"])
        learnable_moves = pokemon.get_move_by_learn_method(
            learn_method=enums.MoveLearnMethod.LEVEL_UP,
            max_level=level,
        )
        moveset = [learnable_move.id for learnable_move in learnable_moves][:-4]
        nature = secrets.randbelow(25) + 1
        evs = EVs.default()
        ivs = IVs.generate(
            min_thresholds=[(20, 6)],
            min_total=120,
            max_total=150,
        )

        return WildPokemon(
            id=pokemon.id,
            name=pokemon.name,
            level=level,
            moveset=moveset,
            nature=nature,
            ivs=ivs.to_dict(),
            evs=evs.to_dict(),
            shiny=False,
            region="Starter",
            location="Starter",
            base_chance=100,
            effective_chance=100,
        )

    def spawn(
        self,
        region: str,
        location: str,
        *,
        min_level: Optional[int] = None,
        max_level: Optional[int] = None,
        multipliers: Optional[Dict[str, float]] = None,
    ) -> "WildPokemon":
        region = region.upper()
        location = location.upper()

        _data_type = enums.DataType.ENCOUNTER
        encounters = self.data[_data_type.value]

        if region not in encounters:
            raise DataTypeError(
                message=f"Region '{region}' not found in encounter data.",
                context=ErrorContext(
                    details={
                        "region": region,
                        "available_regions": list(encounters.keys()),
                    }
                ),
                user_friendly_message=f"The region '{region}' does not exist.",
            )
        if location not in encounters[region]:
            raise DataTypeError(
                message=f"Location '{location}' not found in region '{region}'.",
                context=ErrorContext(
                    details={
                        "location": location,
                        "region": region,
                        "available_locations": list(encounters[region].keys()),
                    }
                ),
                user_friendly_message=f"The location '{location}' does not exist in the '{region}' region.",
            )

        options = encounters[region][location]
        chosen, effective_chance = self._weighted_choice(options, multipliers)

        lvl_min = min_level if min_level is not None else chosen["min_level"]
        lvl_max = max_level if max_level is not None else chosen["max_level"]
        level = secrets.randbelow(lvl_max - lvl_min + 1) + lvl_min

        pokemon = self.get_pokemon(id_or_name=chosen["id"])
        learnable_moves = pokemon.get_move_by_learn_method(
            learn_method=enums.MoveLearnMethod.LEVEL_UP,
            max_level=level,
        )
        moveset = [learnable_move.id for learnable_move in learnable_moves][:-4]
        nature = secrets.randbelow(25) + 1
        is_shiny = secrets.randbelow(4096) == 0
        evs = EVs.default()
        if pokemon.is_legendary or pokemon.is_mythical:
            ivs = IVs.generate(
                min_thresholds=[(22, 3), (15, 3)],
                min_total=120,
            )
        else:
            ivs = IVs.generate()

        return WildPokemon(
            id=pokemon.id,
            name=pokemon.name,
            level=level,
            moveset=moveset,
            nature=nature,
            ivs=ivs.to_dict(),
            evs=evs.to_dict(),
            shiny=is_shiny,
            region=region,
            location=location,
            base_chance=chosen["chance"],
            effective_chance=effective_chance,
        )
