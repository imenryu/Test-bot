from __future__ import annotations

import asyncio

from telegram import LinkPreviewOptions
from telegram.constants import ParseMode, UpdateType
from telegram.ext import Application, Defaults

from pokedex import pokedex

from .config import ConfigManager
from .database import db
from .decorators._rate_limiter import RATE_LIMITER
from .ext import AIORateLimiter, UpdateProcessor
from .locales import locales
from .modules import module_loader
from .router import router


class Bot:
    __slots__ = ("_application",)

    def __init__(self) -> None:
        self._application: "Application" = (
            Application.builder()
            .defaults(self._get_defaults())
            .concurrent_updates(self._get_update_processor())
            .rate_limiter(self._get_rate_limiter())
            .update_queue(self._get_update_queue())
            .post_init(self.initialize)
            .post_stop(self.shutdown)
            .token(ConfigManager.get("TOKEN"))
            .build()
        )

    @property
    def application(self) -> "Application":
        return self._application

    @staticmethod
    def _get_defaults() -> "Defaults":
        defaults: "Defaults" = Defaults(
            parse_mode=ParseMode.HTML,
            disable_notification=True,
            allow_sending_without_reply=True,
            block=True,
            link_preview_options=LinkPreviewOptions(is_disabled=True),
            do_quote=True,
        )
        return defaults

    @staticmethod
    def _get_update_processor() -> "UpdateProcessor":
        update_processor: "UpdateProcessor" = UpdateProcessor(256)
        return update_processor

    @staticmethod
    def _get_rate_limiter() -> "AIORateLimiter":
        rate_limiter: "AIORateLimiter" = AIORateLimiter()
        return rate_limiter

    @staticmethod
    def _get_update_queue() -> "asyncio.Queue":
        update_queue: "asyncio.Queue" = asyncio.Queue()
        return update_queue

    @staticmethod
    def _get_allowed_updates() -> list["UpdateType"]:
        allowed_updates: list["UpdateType"] = [
            UpdateType.MESSAGE,
            UpdateType.CALLBACK_QUERY,
        ]
        return allowed_updates

    @staticmethod
    async def initialize(application: "Application") -> None:
        await db.initialize()
        await RATE_LIMITER.initialize()
        await locales.initialize()
        await pokedex.initialize()
        await router.initialize(application)
        await module_loader.initialize()

    def run(self) -> None:
        allowed_updates: list["UpdateType"] = self._get_allowed_updates()
        return self._application.run_polling(
            allowed_updates=allowed_updates,
            drop_pending_updates=True,
        )

    @staticmethod
    async def shutdown(application: "Application") -> None:
        await db.shutdown()
        await RATE_LIMITER.shutdown()
        await locales.shutdown()
        await pokedex.shutdown()
        await router.shutdown()
        await module_loader.shutdown()
