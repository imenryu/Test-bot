from functools import wraps

from src.config import ConfigManager
from src.utils import extract_data


def owner_only(callback):
    @wraps(callback)
    async def wrapper(update, context):
        user = extract_data(update)[1]
        OWNER_ID = ConfigManager.get_int("OWNER_ID")
        if OWNER_ID == user.id:
            return await callback(update, context)

    return wrapper
