from __future__ import annotations

from functools import wraps
from typing import TYPE_CHECKING

from src.database import db
from src.utils import extract_data

if TYPE_CHECKING:
    from src import enums


def sudo_only(privilege: enums.Privilege = None):
    def decorator(callback):
        @wraps(callback)
        async def wrapper(update, context):
            user = extract_data(update)[1]
            if await db.sudoer.is_user_sudo(user_id=user.id, privilege=privilege):
                return await callback(update, context)

        return wrapper

    return decorator
