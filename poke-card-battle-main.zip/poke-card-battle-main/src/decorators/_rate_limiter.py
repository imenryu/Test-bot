from functools import wraps

from src.cache import UserRateLimiter

RATE_LIMITER = UserRateLimiter()


def rate_limit(callback):
    @wraps(callback)
    async def wrapper(update, context):
        chat_id, user_id = RATE_LIMITER.format_cache(update)
        group_limiter, user_limiter = RATE_LIMITER.get_limiter(
            chat_id, user_id)
        async with group_limiter:
            try:
                await user_limiter.acquire()
            except ValueError as ve:
                expected_message = "Can't acquire more than the maximum capacity"
                if ve == expected_message:
                    return
                raise ValueError(ve)
            else:
                return await callback(update, context)

    return wrapper
