from __future__ import annotations

from typing import TYPE_CHECKING

from telegram import MessageEntity
from telegram.constants import MessageOriginType

from src.database import db
from src.database.types import UserDocument
from src.utils._extract_data import extract_data

if TYPE_CHECKING:
    from telegram import Message, MessageOrigin, Update, User


def _parse_entity_users(message: Message) -> dict[int, User]:
    users: dict[int, User] = {}

    caption_entities: tuple["MessageEntity"] | None = getattr(
        message, "caption_entities", None
    )
    entities: tuple["MessageEntity"] | None = getattr(
        message, "entities", None)

    if entities or caption_entities:
        text_mentions: "MessageEntity" | None = None

        if caption_entities:
            text_mentions = message.parse_caption_entities(
                [
                    MessageEntity.TEXT_MENTION,
                ]
            )

        elif entities:
            text_mentions = message.parse_entities(
                [
                    MessageEntity.TEXT_MENTION,
                ]
            )

        if text_mentions:
            for tm in text_mentions:
                entity_user: User | None = getattr(tm, "user", None)
                if entity_user and entity_user.id not in users:
                    users[entity_user.id] = entity_user

    return users


def _parse_forward_user(message: Message) -> User | None:
    forward_origin: MessageOrigin | None = getattr(
        message, "forward_origin", None)

    if forward_origin and forward_origin.type == MessageOriginType.USER:
        forward_user: User | None = getattr(
            forward_origin, "sender_user", None)
        return forward_user

    return None


def _parse_reply_users(reply_to_message: Message) -> dict[int, User]:
    users: dict[int, User] = {}

    if reply_to_message:
        reply_user: User | None = getattr(reply_to_message, "from_user", None)
        if reply_user:
            users[reply_user.id] = reply_user

        reply_forward_user = _parse_forward_user(message=reply_to_message)
        if reply_forward_user and reply_forward_user.id not in users:
            users[reply_forward_user.id] = reply_forward_user

    return users


def _parse_users(update: Update) -> dict[int, User]:
    _, user, message, reply_to_message, _ = extract_data(update)
    users: dict[int, User] = {user.id: user}

    entity_users: dict[int, User] = _parse_entity_users(message=message)
    forward_user: User | None = _parse_forward_user(message=message)
    reply_users: dict[int, User] = _parse_reply_users(
        reply_to_message=reply_to_message)

    combined: dict[int, User] = {**entity_users, **reply_users}
    for k, v in combined.items():
        if k not in users:
            users[k] = v

    if forward_user and forward_user.id not in users:
        users[forward_user.id] = forward_user

    return users


async def _update_dbuser(users: dict[int, User]) -> None:
    async with db.session.start_transaction() as session:
        for _, user in users.items():
            username: str | None = (
                user.username.lower().replace("@", "")
                if hasattr(user, "username") and user.username is not None
                else None
            )

            dbuser: "UserDocument" | None = await db.user.get_user_by_id(
                user_id=user.id
            )

            if dbuser is None:
                document: "UserDocument" = UserDocument.new_user(
                    user_id=user.id, username=username, is_bot=user.is_bot
                )
                await db.user.add_user(document=document, session=session)

            elif username != dbuser["username"]:
                await db.user.update_user(
                    user_id=user.id, username=username, session=session
                )


async def dbuser_watcher(update: Update) -> None:
    users: dict[int, User] = _parse_users(update=update)
    await _update_dbuser(users=users)
