from typing import Dict

import aiofiles
import yaml
from loguru import logger

from src.constants import CONSTANTS


class LocalesBase:
    """Manages loading and retrieving localized strings from YAML files."""

    __slots__ = ("locales",)

    def __init__(self) -> None:
        self.locales: Dict[str, Dict[str, str]] = {}

    async def initialize(self) -> None:
        try:
            filepath = CONSTANTS.DEFAULT_LOCALES_PATH
            async with aiofiles.open(filepath, mode="r", encoding="utf8") as f:
                content = await f.read()
                data = yaml.safe_load(content)
                if data:
                    self.locales.update(data)
        except (OSError, yaml.YAMLError):
            logger.exception(f"Error parsing locales file: {filepath}")
        else:
            logger.debug(f"{self.__class__.__name__} Initialized")

    async def shutdown(self) -> None:
        self.locales.clear()
        logger.debug(f"{self.__class__.__name__} Shutdown")

    def get(self, section: str, option: str, fallback: str = "") -> str:
        return self.locales.get(section, {}).get(option, fallback)
