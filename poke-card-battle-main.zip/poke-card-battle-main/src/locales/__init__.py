from ._localesbase import LocalesBase

locales = LocalesBase()

__all__ = ("locales",)
