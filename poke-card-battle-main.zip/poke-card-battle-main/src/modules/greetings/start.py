from __future__ import annotations

from typing import TYPE_CHECKING

from telegram.constants import ChatType

from src.database import db
from src.decorators import rate_limit
from src.locales import locales
from src.router import router
from src.utils import extract_data

from .helper import start_args_validation
from .starter_pokemon import send_choose_starter_message

if TYPE_CHECKING:
    from telegram import Update


@router.command("start")
@rate_limit
async def start_command(update: Update, __):
    chat, user, message, _, _ = extract_data(update)
    if chat.type in {ChatType.GROUP, ChatType.SUPERGROUP}:
        txt = locales.get("greetings", "group_start")
        await message.reply_text(text=txt)
    elif chat.type == ChatType.PRIVATE:
        referred_by, redeem_code = await start_args_validation(
            arguments=message.text.split(maxsplit=1)
        )
        if not await db.trainer.is_trainer_exist(user_id=user.id):
            await send_choose_starter_message(update=update)
        else:
            txt = locales.get("greetings", "already_chosen_starter")
            await message.reply_text(text=txt)
