from __future__ import annotations

from typing import TYPE_CHECKING

from src.database import db
from src.decorators import rate_limit
from src.locales import locales
from src.router import router
from src.utils import extract_data

from .helper import get_choose_starter_message

if TYPE_CHECKING:
    from telegram import Update


async def send_choose_starter_message(update: Update) -> None:
    _, user, message, _, _ = extract_data(update)
    if await db.trainer.is_trainer_exist(user_id=user.id):
        txt = locales.get("greetings", "start")
        await message.reply_text(text=txt)
    else:
        text, reply_markup = get_choose_starter_message(user)
        await message.reply_text(text=text, reply_markup=reply_markup)
