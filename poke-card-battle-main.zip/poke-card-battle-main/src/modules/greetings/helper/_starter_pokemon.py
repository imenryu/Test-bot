from __future__ import annotations

from typing import TYPE_CHECKING, List, Tuple

from pokedex.constants import CONSTANTS
from src.locales import locales
from src.modules.helper import CALLBACK_DATA, Pagination

if TYPE_CHECKING:
    from telegram import InlineKeyboardMarkup, User


def _get_choose_starter_reply_markup(user: User) -> InlineKeyboardMarkup:
    keyboard_data: List[Tuple[str]] = []
    for starter in CONSTANTS.STARTER_POKEMON:
        name, dex_id = starter.get("name"), starter.get("id")
        callback_data = CALLBACK_DATA.STARTER.format(
            dex_id=dex_id,
            user_id=user.id,
        )
        keyboard_data.append((name, callback_data))
    reply_markup: InlineKeyboardMarkup = Pagination(
        keyboard_data=keyboard_data,
        x=3,
        y=4,
    )
    return reply_markup


def get_choose_starter_message(user: User) -> Tuple[str, InlineKeyboardMarkup]:
    text: str = locales.get("greetings", "choose_starter_pokemon")
    reply_markup: InlineKeyboardMarkup = _get_choose_starter_reply_markup(user)
    return text, reply_markup
