from typing import List, Optional, Tuple

from src.database import db

ARGS_RETURN_TYPE = Tuple[Optional[int], Optional[str]]


async def start_args_validation(arguments: List[str]) -> ARGS_RETURN_TYPE:
    if len(arguments) != 2:
        return None, None
    referred_by = redeem_code = arguments[1]
    if referred_by.isdigit():
        referred_by = int(referred_by)
        if await db.trainer.is_trainer(user_id=referred_by):
            return referred_by, None
