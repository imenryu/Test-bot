from .core import ModuleLoader

module_loader = ModuleLoader()

__all__ = ("module_loader",)
