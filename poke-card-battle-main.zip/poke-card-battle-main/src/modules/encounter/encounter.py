from __future__ import annotations

from typing import TYPE_CHECKING

from telegram.ext.filters import ChatType

from pokedex import pokedex
from src.decorators import rate_limit
from src.router import router
from src.utils import extract_data

if TYPE_CHECKING:
    from telegram import Update


@router.command("hunt", has_args=False, filters=ChatType.PRIVATE)
@rate_limit
async def encounter_command(update: Update, _) -> None:
    _, _, message, _, _ = extract_data(update)
    wild = pokedex.spawn("KANTO", "VIRIDIAN FOREST")
    poke = pokedex.get_pokemon(wild.id)
    await message.reply_photo(
        photo=poke.sprites.front_default,
        caption=f"You encountered a wild {wild.name} (Lv. {wild.level})",
    )
