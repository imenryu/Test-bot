from __future__ import annotations

from dataclasses import dataclass
from typing import Final


@dataclass(frozen=True, slots=True)
class _CALLBACK_PATTERN:
    POKEDEX_ABOUT: str = r"^pokedex about (\d+) (\d+) (\d)$"
    POKEDEX_BASE_STATS: str = r"^pokedex base-stats (\d+) (\d+)$"
    POKEDEX_EV_YIELDS: str = r"^pokedex ev-yields (\d+)$"
    POKEDEX_LEARNABLE_MOVES: str = r"^pokedex learnable-moves (\d+) (\d+) (\d) (\d+)$"
    STARTER: str = r"^starter (\d+) (\d+)$"


CALLBACK_PATTERN: Final["_CALLBACK_PATTERN"] = _CALLBACK_PATTERN()
