from __future__ import annotations

from dataclasses import dataclass
from typing import Final


@dataclass(frozen=True, slots=True)
class _CALLBACK_DATA:
    POKEDEX_ABOUT: str = "pokedex about {user_id} {dex_id} {edit_or_send}"
    POKEDEX_BASE_STATS: str = "pokedex base-stats {user_id} {dex_id}"
    POKEDEX_EV_YIELDS: str = "pokedex ev-yields {dex_id}"
    POKEDEX_LEARNABLE_MOVES: str = (
        "pokedex learnable-moves {user_id} {dex_id} {learn_method} {offset}"
    )
    STARTER: str = "starter {user_id} {dex_id}"


CALLBACK_DATA: Final["_CALLBACK_DATA"] = _CALLBACK_DATA()
