from __future__ import annotations

from typing import TYPE_CHECKING, Final, List, Tuple

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

if TYPE_CHECKING:
    from telegram import WebAppInfo

BUTTON_TYPES: Final[set[str]] = {
    "callback_data",
    "url",
    "web_app",
}


def _btn(
    text: str,
    value: str | WebAppInfo,
    btn_type: str = "callback_data",
) -> "InlineKeyboardButton":
    if btn_type not in BUTTON_TYPES:
        raise TypeError(
            f"Invalid button type: {btn_type} "
            f"- expected {', '.join(list(BUTTON_TYPES))}"
        )
    return InlineKeyboardButton(text=text, **{btn_type: value})


def Keyboard(rows: List[List[Tuple[str, WebAppInfo]]]) -> "InlineKeyboardMarkup":
    if rows is None:
        rows: List = []

    lines: List[List["InlineKeyboardButton"]] = []
    for coloum in rows:
        line: List["InlineKeyboardButton"] = []
        for btn in coloum:
            if isinstance(btn, str):
                button: "InlineKeyboardButton" = _btn(btn, btn)
            else:
                button: "InlineKeyboardButton" = _btn(*btn)
            line.append(button)
        lines.append(line)
    return InlineKeyboardMarkup(inline_keyboard=lines)


def Pagination(
    keyboard_data: List[Tuple[str]],
    x: int,
    y: int,
) -> "InlineKeyboardMarkup":
    if not isinstance(x, int) or not isinstance(y, int) or x <= 0 or y <= 0:
        raise ValueError("x and y must be positive integers.")

    if not keyboard_data:
        return []

    grid: List[List[Tuple[str]]] = []
    current_index: int = 0

    for _ in range(y):
        row: List[Tuple[str]] = []
        for _ in range(x):
            if current_index < len(keyboard_data):
                row.append(keyboard_data[current_index])
                current_index += 1
        grid.append(row)

    return Keyboard(grid)
