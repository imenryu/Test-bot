from __future__ import annotations

import asyncio
import html
import textwrap
from typing import TYPE_CHECKING, Any, Dict

import aiofiles
from meval import meval

from src import enums
from src.constants import CONSTANTS
from src.decorators import rate_limit, sudo_only
from src.router import router
from src.utils import delete_if_exists, extract_data

from .helper import (
    evaluate_cleanup_code,
    evaluate_format_exception_output,
    evaluate_namespaces,
)

if TYPE_CHECKING:
    from telegram import Message, Update
    from telegram.ext import ContextTypes


async def _evaluate_expression(expression: str, namespaces: Dict[str, Any]) -> Any:
    task = asyncio.create_task(
        meval(expression, globals(), **locals(), **namespaces))
    return await task


async def _handle_output(message: Message, output: Any, code: str) -> None:
    if output is None:
        await message.reply_text("No output.")
        return

    output_str = str(output)
    file_name = CONSTANTS.DEFAULT_EVALUATE_PATH
    try:
        async with aiofiles.open(file_name, mode="w", encoding="utf-8") as f:
            await f.write(textwrap.dedent(output_str))

        await message.reply_document(
            document=file_name, caption=f"<code>{html.escape(code)}</code>"
        )
    finally:
        delete_if_exists(file_name)


@router.command("eval", has_args=True)
@sudo_only(privilege=enums.Privilege.CAN_USE_EVAL)
@rate_limit
async def eval_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = extract_data(update)[2]

    _code = message.text.split(maxsplit=1)
    if len(_code) < 2:
        await message.reply_text("No expression provided.")
        return

    namespaces = evaluate_namespaces(update, context)
    code = evaluate_cleanup_code(_code[-1])

    try:
        output = await _evaluate_expression(code, namespaces)
    except Exception as e:
        output = evaluate_format_exception_output(e)

    await _handle_output(message, output, code)
