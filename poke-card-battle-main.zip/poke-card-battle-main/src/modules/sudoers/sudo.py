from __future__ import annotations

from typing import TYPE_CHECKING

from src.config import ConfigManager
from src.database import db
from src.database.types import Privilege, SudoerDocument
from src.decorators import owner_only, rate_limit
from src.locales import locales
from src.router import router
from src.utils import extract_data

from .helper import sudoer_extract_user

if TYPE_CHECKING:
    from telegram import Update
    from telegram.ext import ContextTypes


@router.command("addsudo")
@owner_only
@rate_limit
async def add_sudo_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    _, dev, message, reply_to_message, _ = extract_data(update)

    user = await sudoer_extract_user(
        message=message,
        reply_to_message=reply_to_message,
        context=context,
    )
    if user is None:
        return

    if await db.sudoer.is_user_sudo(user_id=user.id):
        txt = locales.get("sudoers", "user_already_sudo")
        await message.reply_text(text=txt.format(user=user))
        return

    document = SudoerDocument.new_sudoer(user_id=user.id)
    async with db.session.start_transaction() as session:
        await db.sudoer.grant_sudo(document=document, session=session)

    log_message = locales.get(
        "sudoers", "added_sudo").format(dev=dev, user=user)
    logs_chat = ConfigManager.get_int("LOGS_CHAT")

    await message.reply_text(text=log_message)
    await context.bot.send_message(chat_id=logs_chat, text=log_message)


@router.command(["rmsudo", "removesudo"])
@owner_only
@rate_limit
async def remove_sudo_command(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    _, dev, message, reply_to_message, _ = extract_data(update)

    user = await sudoer_extract_user(
        message=message,
        reply_to_message=reply_to_message,
        context=context,
    )
    if user is None:
        return

    OWNER_ID = ConfigManager.get_int("OWNER_ID")
    if OWNER_ID == user.id:
        txt = locales.get("sudoers", "denied")
        await message.reply_text(text=txt.format(user=user))
        return

    if not await db.sudoer.is_user_sudo(user_id=user.id):
        txt = locales.get("sudoers", "user_not_sudo")
        await message.reply_text(text=txt.format(user=user))
        return

    async with db.session.start_transaction() as session:
        await db.sudoer.revoke_sudo(user_id=user.id, session=session)

    log_message = locales.get(
        "sudoers", "removed_sudo").format(dev=dev, user=user)
    logs_chat = ConfigManager.get_int("LOGS_CHAT")

    await message.reply_text(text=log_message)
    await context.bot.send_message(chat_id=logs_chat, text=log_message)
