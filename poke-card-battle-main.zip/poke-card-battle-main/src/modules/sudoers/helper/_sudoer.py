from __future__ import annotations

from typing import TYPE_CHECKING

from telegram import MessageEntity
from telegram.error import BadRequest

from src.database import db
from src.locales import locales

if TYPE_CHECKING:
    from telegram import Message, User
    from telegram.ext import ContextTypes


async def sudoer_extract_user(
    message: Message,
    reply_to_message: Message,
    context: ContextTypes.DEFAULT_TYPE,
) -> User | None:
    if reply_to_message:
        user = reply_to_message.from_user
        if user.is_bot:
            txt = locales.get("general", "bot_not_allowed")
            await message.reply_text(text=txt)
            return None
        return user
    else:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            txt = locales.get("general", "missing_arguments").format("user_id")
            await message.reply_text(text=txt)
            return None

        user_id: int = None
        argument = args[1]
        if argument.isdigit():
            user_id = argument
        elif message.entities:
            entities = message.parse_entities(
                [MessageEntity.TEXT_MENTION, MessageEntity.MENTION]
            )
            if entities:
                for ent in entities:
                    match ent.type:
                        case MessageEntity.TEXT_MENTION:
                            user_id = ent.user.id
                            break
                        case MessageEntity.MENTION:
                            username = entities.get(ent, argument)
                            dbuser = await db.user.get_user_by_username(
                                username=username
                            )
                            if dbuser is not None:
                                user_id = dbuser["user_id"]
                                break

        else:
            txt = locales.get("general", "user_not_found")
            await message.reply_text(text=txt)
            return None

        if user_id is None:
            txt = locales.get("general", "invalid_user_format")
            await message.reply_text(text=txt)
            return None

        try:
            user_id = int(user_id)
        except ValueError:
            txt = locales.get("general", "invalid_user_id")
            await message.reply_text(text=txt)
            return None

        try:
            dbuser = await db.user.get_user_by_id(user_id=user_id)
            if dbuser and dbuser["is_bot"]:
                txt = locales.get("general", "bot_not_allowed")
                await message.reply_text(text=txt)
                return None

            user = await context.bot.get_chat(user_id)

        except BadRequest as br:
            expected_message = "Chat not found"
            if expected_message == str(br):
                txt = locales.get("general", "user_not_found")
                await message.reply_text(text=txt)
                return None

            raise BadRequest(br)

        else:
            return user

        return None
