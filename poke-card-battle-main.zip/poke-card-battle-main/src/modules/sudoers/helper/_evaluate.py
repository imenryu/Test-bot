from __future__ import annotations

import sys
import traceback
from typing import TYPE_CHECKING, Dict, Union

from src.utils import extract_data

if TYPE_CHECKING:
    from telegram import CallbackQuery, Chat, Message, Update, User
    from telegram.ext import ContextTypes, ExtBot


def evaluate_cleanup_code(code: str) -> str:
    if code.startswith("```") and code.endswith("```"):
        return "\n".join(code.split("\n")[1:-1])
    return code.strip("` \n")


def evaluate_format_exception_output(e: "Exception") -> str:
    etype, value, tb = sys.exc_info()
    if not (etype and value and tb):
        _formatted_exc = traceback.format_exc()
    else:
        _formatted_exc = traceback.format_exception(etype, value, tb)

    formatted_exc: str = (
        "".join(_formatted_exc) if isinstance(
            _formatted_exc, list) else _formatted_exc
    )
    output = f"{e}\n\n{formatted_exc}"
    return output


def evaluate_namespaces(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> Dict[
    str,
    Union[
        CallbackQuery,
        Chat,
        ContextTypes.DEFAULT_TYPE,
        ExtBot,
        Message,
        Update,
        User,
    ],
]:
    chat, user, message, reply_to_message, callback_query = extract_data(
        update)
    namespaces = {
        "update": update,
        "context": context,
        "bot": context.bot,
        "user": user,
        "chat": chat,
        "message": message,
        "reply_to_message": reply_to_message,
        "callback_query": callback_query,
    }
    return namespaces
