from __future__ import annotations

from typing import TYPE_CHECKING, Final, List, Tuple

from loguru import logger

from pokedex import pokedex
from src.locales import locales
from src.modules.helper import CALLBACK_DATA, Keyboard

if TYPE_CHECKING:
    from telegram import InlineKeyboardMarkup, User

    from pokedex.models.pokemon import Pokemon, PokemonLearnableMove

MOVES_PER_PAGE: Final[int] = 5


def _get_pokemon_learnable_moves_reply_markup(
    user: User,
    pokemon: Pokemon,
    learn_method: int,
    offset: int,
) -> InlineKeyboardMarkup:
    keyboard: List[List[Tuple[str]]] = []

    moves: List[PokemonLearnableMove] = pokemon.get_move_by_learn_method(
        learn_method)
    total_moves: int = len(moves)

    has_previous: bool = offset > 0
    has_next: bool = offset + MOVES_PER_PAGE < total_moves

    current_page: int = (offset // MOVES_PER_PAGE) + 1
    total_pages: int = (total_moves + MOVES_PER_PAGE - 1) // MOVES_PER_PAGE
    last_page: int = current_page == total_pages

    level_up = tutor = machine = None

    if learn_method == 1:
        level_up = ("• Level Up •", "ignore")
        tutor = (
            "Tutor",
            CALLBACK_DATA.POKEDEX_LEARNABLE_MOVES.format(
                user_id=user.id,
                dex_id=pokemon.id,
                learn_method=3,
                offset=0,
            ),
        )
        machine = (
            "TM / TR",
            CALLBACK_DATA.POKEDEX_LEARNABLE_MOVES.format(
                user_id=user.id,
                dex_id=pokemon.id,
                learn_method=4,
                offset=0,
            ),
        )
    elif learn_method == 3:
        level_up = (
            "Level Up",
            CALLBACK_DATA.POKEDEX_LEARNABLE_MOVES.format(
                user_id=user.id,
                dex_id=pokemon.id,
                learn_method=1,
                offset=0,
            ),
        )
        tutor = ("• Tutor •", "ignore")
        machine = (
            "TM / TR",
            CALLBACK_DATA.POKEDEX_LEARNABLE_MOVES.format(
                user_id=user.id,
                dex_id=pokemon.id,
                learn_method=4,
                offset=0,
            ),
        )
    elif learn_method == 4:
        level_up = (
            "Level Up",
            CALLBACK_DATA.POKEDEX_LEARNABLE_MOVES.format(
                user_id=user.id,
                dex_id=pokemon.id,
                learn_method=1,
                offset=0,
            ),
        )
        tutor = (
            "Tutor",
            CALLBACK_DATA.POKEDEX_LEARNABLE_MOVES.format(
                user_id=user.id,
                dex_id=pokemon.id,
                learn_method=3,
                offset=0,
            ),
        )
        machine = ("• TM / TR •", "ignore")

    if level_up and tutor and machine:
        keyboard.append([level_up, tutor, machine])

    navigation_buttons: List[Tuple[str]] = []
    if has_previous:
        navigation_buttons.append(
            (
                "Previous",
                CALLBACK_DATA.POKEDEX_LEARNABLE_MOVES.format(
                    user_id=user.id,
                    dex_id=pokemon.id,
                    learn_method=learn_method,
                    offset=offset - MOVES_PER_PAGE,
                ),
            )
        )
    navigation_buttons.append((f"{current_page}/{total_pages}", "ignore"))
    if has_next and not last_page:
        navigation_buttons.append(
            (
                "Next",
                CALLBACK_DATA.POKEDEX_LEARNABLE_MOVES.format(
                    user_id=user.id,
                    dex_id=pokemon.id,
                    learn_method=learn_method,
                    offset=offset + MOVES_PER_PAGE,
                ),
            )
        )

    if navigation_buttons:
        keyboard.append(navigation_buttons)

    keyboard.append(
        [
            (
                "Back to Pokemon",
                CALLBACK_DATA.POKEDEX_ABOUT.format(
                    user_id=user.id,
                    dex_id=pokemon.id,
                    edit_or_send=0,
                ),
            )
        ]
    )
    reply_markup: InlineKeyboardMarkup = Keyboard(keyboard)
    return reply_markup


def get_pokemon_learnable_moves(
    user: User,
    pokemon: Pokemon,
    learn_method: int,
    offset: int,
) -> Tuple[str, InlineKeyboardMarkup]:
    try:
        learnable_moves: List[PokemonLearnableMove] = pokemon.get_move_by_learn_method(
            learn_method
        )[offset: offset + MOVES_PER_PAGE]
    except (IndexError, ValueError):
        learnable_moves: List = []
        logger.warning(
            f"Offset {offset} is out of range for {pokemon.name} learnable moves."
        )

    if not learnable_moves:
        return "No more learnable moves found.", Keyboard(
            [
                [
                    (
                        "Back to Pokemon",
                        CALLBACK_DATA.POKEDEX_ABOUT.format(
                            user_id=user.id,
                            dex_id=pokemon.id,
                            edit_or_send=0,
                        ),
                    )
                ]
            ]
        )

    caption: str = "<b><u>Learnable Moves</u></b>\n"
    for learnable_move in learnable_moves:
        move = pokedex.get_move(learnable_move.id)
        if not move:
            continue
        move_about: str = locales.get("pokedex", "pokemon_learnable_moves")
        caption += "\n\n" + move_about.format(
            move=move,
            move_type=move.type.value,
            damage_class=move.damage_class.value,
            min_level=learnable_move.min_level,
        )

    reply_markup: InlineKeyboardMarkup = _get_pokemon_learnable_moves_reply_markup(
        user,
        pokemon,
        learn_method,
        offset,
    )
    return caption, reply_markup
