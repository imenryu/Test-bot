from __future__ import annotations

from typing import TYPE_CHECKING, List, Tuple

from loguru import logger

from pokedex import pokedex
from src.locales import locales
from src.modules.helper import CALLBACK_DATA, Keyboard

if TYPE_CHECKING:
    from telegram import InlineKeyboardMarkup, User

    from pokedex.models.pokemon import Pokemon, PokemonEvolvesTo


def _get_pokemon_about_reply_markup(
    user: User,
    pokemon: Pokemon,
) -> InlineKeyboardMarkup:
    keyboard: List[List[Tuple[str]]] = []

    evolution_buttons: List[Tuple[str]] = []
    if pokemon.evolves_from:
        try:
            evolves_from: Pokemon = pokedex.get_pokemon(pokemon.evolves_from)
            evolution_buttons.append(
                (
                    evolves_from.name.capitalize(),
                    CALLBACK_DATA.POKEDEX_ABOUT.format(
                        user_id=user.id,
                        dex_id=evolves_from.id,
                        edit_or_send=1,
                    ),
                )
            )
        except Exception:
            logger.exception(
                f"Error fetching evolution data for: {pokemon.name}",
            )
    if pokemon.evolves_to:
        try:
            evolves_to: PokemonEvolvesTo = pokemon.evolves_to
            evolution_buttons.append(
                (
                    f"{evolves_to.name.capitalize()} (min lvl {pokemon.evolves_to.min_level})",
                    CALLBACK_DATA.POKEDEX_ABOUT.format(
                        user_id=user.id,
                        dex_id=evolves_to.id,
                        edit_or_send=1,
                    ),
                )
            )
        except Exception:
            logger.exception(
                f"Error fetching evolution data for: {pokemon.name}",
            )

    if evolution_buttons:
        keyboard.append(evolution_buttons)

    keyboard.append(
        [
            (
                "Base Stats",
                CALLBACK_DATA.POKEDEX_BASE_STATS.format(
                    user_id=user.id, dex_id=pokemon.id
                ),
            ),
            (
                "EV yields",
                CALLBACK_DATA.POKEDEX_EV_YIELDS.format(dex_id=pokemon.id),
            ),
        ]
    )

    keyboard.append(
        [
            (
                "Learnable Moves",
                CALLBACK_DATA.POKEDEX_LEARNABLE_MOVES.format(
                    user_id=user.id,
                    dex_id=pokemon.id,
                    learn_method=1,
                    offset=0,
                ),
            )
        ]
    )
    reply_markup: InlineKeyboardMarkup = Keyboard(keyboard)
    return reply_markup


def _get_pokemon_about_caption(pokemon: Pokemon) -> str:
    caption: str = locales.get("pokedex", "pokemon_about")
    return caption.format(
        poke=pokemon,
        types=", ".join(type.value.capitalize() for type in pokemon.types),
        growth_rate=pokemon.growth_rate.value.capitalize(),
    )


def get_pokemon_about(user: User, pokemon: Pokemon) -> Tuple[str, InlineKeyboardMarkup]:
    photo: str = pokemon.sprites.front_default
    caption: str = _get_pokemon_about_caption(pokemon)
    reply_markup: InlineKeyboardMarkup = _get_pokemon_about_reply_markup(
        user, pokemon)
    return photo, caption, reply_markup


def get_similar_pokemon(
    user: User, pokemon: List[Pokemon]
) -> Tuple[str, InlineKeyboardMarkup]:
    keyboard: List[List[Tuple[str]]] = []
    for poke in pokemon:
        keyboard.append(
            [
                (
                    poke.name,
                    CALLBACK_DATA.POKEDEX_ABOUT.format(
                        user_id=user.id,
                        dex_id=poke.id,
                        edit_or_send=1,
                    ),
                )
            ]
        )
    text: str = locales.get("pokedex", "similar_pokemon")
    reply_markup: InlineKeyboardMarkup = Keyboard(keyboard)
    return text, reply_markup
