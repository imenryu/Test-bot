from __future__ import annotations

from typing import TYPE_CHECKING, List, Tuple

from src.locales import locales
from src.modules.helper import CALLBACK_DATA, Keyboard

if TYPE_CHECKING:
    from telegram import InlineKeyboardMarkup, User

    from pokedex.models.pokemon import Pokemon


def get_pokemon_base_stats(
    user: User,
    pokemon: Pokemon,
) -> Tuple[str, InlineKeyboardMarkup]:
    caption: str = locales.get("pokedex", "pokemon_basestats")
    keyboard: List[List[Tuple[str]]] = [
        [
            (
                "Back to Pokemon",
                CALLBACK_DATA.POKEDEX_ABOUT.format(
                    user_id=user.id,
                    dex_id=pokemon.id,
                    edit_or_send=0,
                ),
            )
        ]
    ]
    reply_markup: InlineKeyboardMarkup = Keyboard(keyboard)
    return caption.format(stats=pokemon.base_stats), reply_markup


def get_pokemon_ev_yields(pokemon: Pokemon) -> str:
    caption, evs = locales.get("pokedex", "pokemon_ev_yields"), ""
    for stat, ev_yield in pokemon.ev_yields.items():
        evs += f"\n\n+{ev_yield} {stat}"
    return caption.format(name=pokemon.name.capitalize(), evs=evs)
