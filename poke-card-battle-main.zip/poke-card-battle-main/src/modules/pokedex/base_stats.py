from __future__ import annotations

import re
from contextlib import suppress
from typing import TYPE_CHECKING

from telegram.error import BadRequest

from pokedex import pokedex
from src.decorators import rate_limit
from src.modules.helper import CALLBACK_PATTERN
from src.router import router
from src.utils import extract_data

from .helper import (
    get_pokemon_base_stats,
    get_pokemon_ev_yields,
)

if TYPE_CHECKING:
    from telegram import Update


@router.callback_query(CALLBACK_PATTERN.POKEDEX_EV_YIELDS)
@rate_limit
async def pokemon_ev_yields_callback(update: Update, _) -> None:
    callback_query = extract_data(update)[4]
    matches = re.match(CALLBACK_PATTERN.POKEDEX_EV_YIELDS, callback_query.data)
    dex_id = int(matches.group(1))
    pokemon = pokedex.get_pokemon(dex_id)
    ev_yields = get_pokemon_ev_yields(pokemon)
    await callback_query.answer(ev_yields, show_alert=True)


@router.callback_query(CALLBACK_PATTERN.POKEDEX_BASE_STATS)
@rate_limit
async def pokemon_base_stats_callback(update: Update, __) -> None:
    _, user, _, _, callback_query = extract_data(update)
    matches = re.match(CALLBACK_PATTERN.POKEDEX_BASE_STATS,
                       callback_query.data)

    user_id = int(matches.group(1))
    if user.id != user_id:
        return await callback_query.answer("you cannot use this.")

    await callback_query.answer()
    dex_id = int(matches.group(2))
    pokemon = pokedex.get_pokemon(dex_id)
    caption, reply_markup = get_pokemon_base_stats(user, pokemon)
    with suppress(BadRequest):
        await callback_query.edit_message_caption(
            caption=caption, reply_markup=reply_markup
        )
