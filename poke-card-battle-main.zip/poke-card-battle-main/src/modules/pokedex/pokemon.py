from __future__ import annotations

import re
from contextlib import suppress
from typing import TYPE_CHECKING

from telegram import InputMediaPhoto, PhotoSize
from telegram._utils.files import parse_file_input
from telegram.error import BadRequest

from pokedex import pokedex
from pokedex.errors import InvalidPokemonID, InvalidPokemonName
from src.decorators import rate_limit
from src.modules.helper import CALLBACK_PATTERN
from src.router import router
from src.utils import extract_data

from .helper import get_pokemon_about, get_similar_pokemon

if TYPE_CHECKING:
    from telegram import Update


@router.command("pokedex", has_args=True)
@rate_limit
async def pokedex_command(update: Update, __) -> None:
    _, user, message, _, _ = extract_data(update)

    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text("No expression provided.")
        return

    id_or_name = args[1]
    with suppress(ValueError):
        id_or_name = int(id_or_name)

    try:
        pokemon = pokedex.get_pokemon(id_or_name)
    except (InvalidPokemonID, InvalidPokemonName) as e:
        await message.reply_text(e.user_friendly_message)
        return

    if not pokemon:
        await message.reply_text("something went wrong")
    elif isinstance(pokemon, list):
        text, reply_markup = get_similar_pokemon(user, pokemon)
        await message.reply_text(
            text=text,
            reply_markup=reply_markup,
        )
    else:
        photo, caption, reply_markup = get_pokemon_about(user, pokemon)
        await message.reply_photo(
            photo=photo,
            caption=caption,
            reply_markup=reply_markup,
        )


@router.callback_query(CALLBACK_PATTERN.POKEDEX_ABOUT)
@rate_limit
async def pokedex_callback(update: Update, ___) -> None:
    __, user, __, __, callback_query = extract_data(update)
    matches = re.match(CALLBACK_PATTERN.POKEDEX_ABOUT, callback_query.data)

    user_id = int(matches.group(1))
    if user.id != user_id:
        return await callback_query.answer("you cannot use this.")

    await callback_query.answer()
    dex_id = int(matches.group(2))
    pokemon = pokedex.get_pokemon(dex_id)

    photo, caption, reply_markup = get_pokemon_about(user, pokemon)
    match matches.group(3):
        case "0":
            with suppress(BadRequest):
                await callback_query.edit_message_caption(
                    caption=caption,
                    reply_markup=reply_markup,
                )
        case "1":
            media = parse_file_input(file_input=photo, tg_type=PhotoSize)
            with suppress(BadRequest):
                await callback_query.edit_message_media(
                    media=InputMediaPhoto(
                        media=media,
                        caption=caption,
                    ),
                    reply_markup=reply_markup,
                )
        case _:
            await callback_query.message.reply_text("something went wrong")
