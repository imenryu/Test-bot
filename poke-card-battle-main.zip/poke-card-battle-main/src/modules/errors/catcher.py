from __future__ import annotations

import html
import random
import time
from collections import OrderedDict
from typing import TYPE_CHECKING, Final

import aiofiles
from telegram.constants import ChatType
from telegram.error import BadRequest

from src.config import ConfigManager
from src.modules.helper import Keyboard
from src.router import router
from src.utils import delete_if_exists, extract_data, paspybin

from .helper import get_pretty_message, get_traceback

if TYPE_CHECKING:
    from telegram import Update
    from telegram.ext import ContextTypes


class ErrorsDict(OrderedDict):
    """ErrorsDict with size-based LRU auto-expiry"""

    def __init__(self, max_size: int = 100):
        super().__init__()
        self.max_size = max_size

    def __contains__(self, error):
        for e in self:
            if type(e) is type(error) and e.args == error.args:
                self[e]["count"] += 1
                self.move_to_end(e)
                return True

        error.identifier = "".join(
            random.choices("ABCDEFGHJKLMNPQRSTUVWXYZ23456789", k=4)
        )
        self[error] = {"count": 0, "time": time.time()}
        if len(self) > self.max_size:
            self.popitem(last=False)

        return False


errors: Final["ErrorsDict"] = ErrorsDict()
ERROR_FILE: Final[str] = "error.txt"


@router.error()
async def error_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update:
        return

    chat = extract_data(update)[0]

    if chat and chat.type != ChatType.CHANNEL:
        e = html.escape(
            str(
                getattr(
                    context.error,
                    "user_friendly_message",
                    context.error,
                )
            )
        )
        try:
            await context.bot.send_message(
                chat_id=chat.id,
                text=(
                    f"<b>Sorry I ran into an error!</b>\n<b>Error</b>: <code>{e}</code>\n"
                    "<i>This incident has been logged. No further action is required.</i>"
                ),
            )
        except BadRequest as br:
            expected_message = "enough rights to send"
            if expected_message not in br:
                raise BadRequest(br)

    if context.error in errors:
        return

    e = html.escape(str(context.error))
    traceback = get_traceback(context)
    pretty_message = get_pretty_message(update, traceback)
    title = f"#{context.error.identifier}\n<b>Unhandled exception caught:</b>\n<code>{e}</code>"
    logs_chat = ConfigManager.get_int("LOGS_CHAT")

    if paste_key := await paspybin(pretty_message):
        paste_url = f"pastebin.com/{paste_key}"
        keyboard = [[("PrivateBin", paste_url, "url")]]
        reply_markup = Keyboard(keyboard)
        await context.bot.send_message(
            chat_id=logs_chat,
            text=title,
            reply_markup=reply_markup,
        )
    else:
        async with aiofiles.open(ERROR_FILE, "w") as f:
            await f.write(pretty_message)
        await context.bot.send_document(
            chat_id=logs_chat,
            document=ERROR_FILE,
            caption=title,
        )
        delete_if_exists(ERROR_FILE)
