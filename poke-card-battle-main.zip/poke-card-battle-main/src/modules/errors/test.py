from src.decorators import rate_limit, sudo_only
from src.router import router


@router.command("testerror")
@sudo_only()
@rate_limit
async def test_error_command(_, __):
    msg = "Test Error Message"
    raise Exception(msg)
