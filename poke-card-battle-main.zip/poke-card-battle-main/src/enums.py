from enum import StrEnum


class Privilege(StrEnum):
    CAN_GIFT_CURRENCY = "can_gift_currency"
    CAN_GIFT_POKEMON = "can_gift_pokemon"
    CAN_GIFT_RESOURCE = "can_gift_resource"
    CAN_ORGANISE_RAID = "can_organise_raid"
    CAN_MODIFY_POKEMON = "can_modify_pokemon"
    CAN_MODIFY_TRAINER = "can_modify_trainer"
    CAN_USE_EVAL = "can_use_eval"
