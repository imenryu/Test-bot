import uvloop

from . import BOT, health_checker

uvloop.install()


def main() -> None:
    health_checker.check()

    BOT.run()


if __name__ == "__main__":
    main()
