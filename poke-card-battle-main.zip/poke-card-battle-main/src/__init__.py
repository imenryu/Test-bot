from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Final

from .bot import Bot

if TYPE_CHECKING:
    from telegram.ext import Application
#     from src.modules.encounter import Encounter, WildBattle

BOT: Final["Bot"] = Bot()
APPLICATION: Final[Application] = BOT.application


class GlobalState:
    build_time: "datetime" = datetime.utcnow().replace(microsecond=0)
    maintenance_mode: bool = False
    """
    encounter: Dict[int, Encounter] = {}
    encounter_lock: "asyncio.Lock" = asyncio.Lock()
  
    wild_battle: Dict[int, WildBattle] = {}
    wild_battle_lock: "asyncio.Lock" = asyncio.Lock()
    """


__all__ = (
    "APPLICATION",
    "BOT",
    "GlobalState",
)
