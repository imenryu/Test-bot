from .base import AplicationError, ErrorContext
from .exceptions import (
    DatabaseError,
    DBOperationFailed,
    DocumentCorrupted,
    DuplicateDocument,
    InvalidDocumentFields,
    InvalidUUID,
    UnknownError,
    UUIDGenerationFailed,
)

__all__ = (
    "AplicationError",
    "ErrorContext",
    "UnknownError",
    "DatabaseError",
    "DBOperationFailed",
    "DocumentCorrupted",
    "InvalidDocumentFields",
    "InvalidUUID",
    "UUIDGenerationFailed",
    "DuplicateDocument",
)
