from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Optional, Union

from .base import AplicationError

if TYPE_CHECKING:
    from .base import ErrorContext


class UnknownError(AplicationError):
    """
    Raised for unknown error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69069,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class DatabaseError(AplicationError):
    """
    Raised for database error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69001,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class DBOperationFailed(DatabaseError):
    """
    Raised for database opration failed error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69002,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class DocumentCorrupted(DatabaseError):
    """
    Raised for database document corrupted or invalid.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69003,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class InvalidDocumentFields(DocumentCorrupted):
    """
    Raised for invalid document fields.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69004,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class InvalidUUID(InvalidDocumentFields):
    """
    Raised for database opration failed error.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69005,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class UUIDGenerationFailed(DatabaseError):
    """
    Raised for uuid generation failed.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69006,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )


class DuplicateDocument(DatabaseError):
    """
    Raised for duplicate database document.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[int] = 69007,
        context: Optional[Union[Mapping[str, Any], ErrorContext]] = None,
        user_friendly_message: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            error_code=error_code,
            context=context,
            user_friendly_message=user_friendly_message,
        )
