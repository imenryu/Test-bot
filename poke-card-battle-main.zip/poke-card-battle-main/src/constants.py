from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Final


@dataclass(frozen=True, slots=True)
class _CONSTANTS:
    BOT_ROOT_PATH: "Path" = Path(__file__).parent.parent
    XDG_RAWDATA_HOME: str = f"{BOT_ROOT_PATH}/src/rawdata"
    XDG_TEMP_PATH: str = "/tmp"

    EVALUATE_FILE_NAME: str = "evaluate.txt"
    LOCALES_FILE_NAME: str = "locales.yaml"

    DEFAULT_EVALUATE_PATH: str = f"{XDG_TEMP_PATH}/{EVALUATE_FILE_NAME}"
    DEFAULT_LOCALES_PATH: str = f"{XDG_RAWDATA_HOME}/{LOCALES_FILE_NAME}"


CONSTANTS: Final["_CONSTANTS"] = _CONSTANTS()
