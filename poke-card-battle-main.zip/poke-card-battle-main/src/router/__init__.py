from ._handler import TelegramHandler

router = TelegramHandler()

__all__ = ("router",)
