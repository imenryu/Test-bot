from __future__ import annotations

from contextlib import nullcontext
from dataclasses import dataclass
from typing import TYPE_CHECKING, Tuple, Union

from aiolimiter import AsyncLimiter
from cachetools import LRUCache
from loguru import logger
from telegram.constants import ChatType

from src.utils import extract_data

if TYPE_CHECKING:
    from telegram import Update


@dataclass(frozen=True, slots=True)
class UserRateLimiterConfig:
    group_max_rate: int = 1
    group_time_period: int = 1
    group_cache_size: int = 1024

    user_max_rate: int = 1
    user_time_period: int = 1
    user_cache_size: int = 2048


class UserRateLimiter:
    __slots__ = ("_config", "_group_limiters", "_user_limiters")

    def __init__(self):
        cfg = UserRateLimiterConfig()
        self._config = cfg
        self._group_limiters: LRUCache[int, "AsyncLimiter"] = LRUCache(
            maxsize=cfg.group_cache_size,
        )
        self._user_limiters: LRUCache[int, "AsyncLimiter"] = LRUCache(
            maxsize=cfg.user_cache_size,
        )

    async def initialize(self) -> None:
        logger.debug(f"{self.__class__.__name__} Initialized")

    async def shutdown(self) -> None:
        self._group_limiters.clear()
        self._user_limiters.clear()
        logger.debug(f"{self.__class__.__name__} Shutdown")

    def _get_user_limiter(self, user_id: int) -> Union["AsyncLimiter", "nullcontext"]:
        if user_id is None:
            return nullcontext()

        if user_id not in self._user_limiters:
            self._user_limiters[user_id] = AsyncLimiter(
                max_rate=self._config.user_max_rate,
                time_period=self._config.user_time_period,
            )
        return self._user_limiters[user_id]

    def _get_group_limiter(
        self, chat_id: Union[int, str]
    ) -> Union["AsyncLimiter", "nullcontext"]:
        if chat_id is None:
            return nullcontext()

        if chat_id not in self._group_limiters:
            self._group_limiters[chat_id] = AsyncLimiter(
                max_rate=self._config.group_max_rate,
                time_period=self._config.group_time_period,
            )
        return self._group_limiters[chat_id]

    @staticmethod
    def format_cache(update: Update) -> Tuple[int, str]:
        chat, user, _, _, _ = extract_data(update)
        chat_id: Union[int, str] = (
            chat.id
            if chat
            and chat.type
            in (
                ChatType.GROUP,
                ChatType.SUPERGROUP,
                ChatType.PRIVATE,
            )
            else None
        )
        return chat_id, user.id

    def get_limiter(
        self, chat_id: Union[int, str], user_id: int
    ) -> Tuple[Union["AsyncLimiter", "nullcontext"]]:
        group_limiter = self._get_user_limiter(chat_id)
        user_limiter = self._get_user_limiter(user_id)
        return group_limiter, user_limiter
