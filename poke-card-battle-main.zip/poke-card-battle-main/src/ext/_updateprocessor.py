from __future__ import annotations

from typing import TYPE_CHECKING, Coroutine

from loguru import logger
from telegram.ext import BaseUpdateProcessor

from src.cache import UserSemaphore, UserUpdates
from src.utils._dbuser_watcher import dbuser_watcher

if TYPE_CHECKING:
    from telegram import Update

Semaphore = UserSemaphore()
Updates = UserUpdates()


class UpdateProcessor(BaseUpdateProcessor):
    async def initialize(self) -> None:
        await Semaphore.initialize(name=self.__class__.__name__)
        await Updates.initialize(name=self.__class__.__name__)
        logger.debug(f"{self.__class__.__name__} Initialized")

    async def shutdown(self) -> None:
        await Semaphore.shutdown(name=self.__class__.__name__)
        await Updates.shutdown(name=self.__class__.__name__)
        logger.debug(f"{self.__class__.__name__} Shutdown")

    async def do_process_update(
        self,
        update: Update,
        coroutine: Coroutine,
    ) -> None:
        chat_id, user_id, cache_key, cache_value = Updates.format_cache(
            update=update)
        if user_id and cache_key and cache_value:
            check_update = await Updates.check_update(
                user_id=user_id,
                key=cache_key,
                value=cache_value,
            )
            if check_update:
                coroutine.close()
                return

            Updates.add_update(key=cache_key, value=cache_value)

        if user_id is None:
            await coroutine
        else:
            await dbuser_watcher(update=update)
            group_context = Updates.get_group_limiter(chat_id=chat_id)
            semaphore = Semaphore.get(user_id=user_id)
            async with group_context, semaphore:
                await coroutine
