from __future__ import annotations

from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, AsyncGenerator

from loguru import logger

from src.errors import DBOperationFailed, ErrorContext

if TYPE_CHECKING:
    from motor.motor_asyncio import AsyncIOMotorClient, ClientSession


class SessionManager:
    """
    Handles MongoDB transaction session management.

    Provides context-managed transactional safety.
    """

    __slots__ = ("_client",)

    def __init__(self, client: AsyncIOMotorClient) -> None:
        self._client: AsyncIOMotorClient = client

    @asynccontextmanager
    async def start_transaction(self) -> AsyncGenerator[ClientSession, None]:
        """
        Context manager for safe transactional operations.
        Automatically commits or aborts on exceptions.
        """
        session = await self._client.start_session()
        session.start_transaction()

        try:
            yield session
            await session.commit_transaction()

        except Exception as e:
            await session.abort_transaction()
            logger.exception(f"Transaction aborted due to error: {e}")

            raise DBOperationFailed(
                message=f"Transaction failed: {e!r}",
                context=ErrorContext(
                    details={
                        "error_type": type(e).__name__,
                        "error_message": str(e),
                    }
                ),
                user_friendly_message="A database transaction error occurred. Please try again later.",
            ) from e

        finally:
            await session.end_session()
