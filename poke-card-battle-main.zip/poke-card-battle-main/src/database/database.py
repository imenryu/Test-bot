from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from loguru import logger
from motor.motor_asyncio import AsyncIOMotorClient

from src.cache import UserSemaphore
from src.config import ConfigManager

from .models import Pokemon, Sudoer, Trainer, User
from .sessionmanager import SessionManager

if TYPE_CHECKING:
    from motor.motor_asyncio import AsyncIOMotorDatabase


class Database:
    __slots__ = (
        "_client",
        "_database",
        "_session",
        "_pokemon",
        "_sudoer",
        "_trainer",
        "_user",
        "_semaphore",
    )

    def __init__(self) -> None:
        DB_URI = ConfigManager.get("DB_URI")
        client: "AsyncIOMotorClient" = AsyncIOMotorClient(DB_URI)
        database: AsyncIOMotorDatabase = client.get_default_database()
        session: "SessionManager" = SessionManager(client=client)
        semaphore: "UserSemaphore" = UserSemaphore()

        self._client: "AsyncIOMotorClient" = client
        self._database: AsyncIOMotorDatabase = database
        self._session: "SessionManager" = session
        self._semaphore: "UserSemaphore" = semaphore

        self._pokemon: "Pokemon" = Pokemon(
            client=client, database=database, semaphore=semaphore
        )
        self._sudoer: "Sudoer" = Sudoer(
            client=client, database=database, semaphore=semaphore
        )
        self._trainer: "Trainer" = Trainer(
            client=client, database=database, semaphore=semaphore
        )
        self._user: "User" = User(
            client=client, database=database, semaphore=semaphore)

    async def initialize(self) -> None:
        await self._semaphore.initialize(name=self.__class__.__name__)
        await asyncio.gather(
            self._pokemon.initialize(),
            self._sudoer.initialize(),
            self._trainer.initialize(),
            self._user.initialize(),
        )
        await self._initialize_sudo()
        logger.debug(f"{self.__class__.__name__} Initialized")

    async def shutdown(self) -> None:
        await self._semaphore.shutdown(name=self.__class__.__name__)
        await asyncio.gather(
            self._pokemon.shutdown(),
            self._sudoer.shutdown(),
            self._trainer.shutdown(),
            self._user.shutdown(),
        )
        if hasattr(self._client, "close"):
            self._client.close()
        logger.debug(f"{self.__class__.__name__} Shutdown")

    async def _initialize_sudo(self) -> None:
        user_id = ConfigManager.get_int("OWNER_ID")
        if not await self._sudoer.is_user_sudo(user_id=user_id):
            logger.debug(f"[{self.__class__.__name__}] Setting up `OWNER_ID`")
            from .types import Privilege, SudoerDocument

            document = SudoerDocument.new_sudoer(
                user_id=user_id, privilege=Privilege.grant_all()
            )
            async with self.session.start_transaction() as session:
                await self.sudoer.grant_sudo(document=document, session=session)

    @property
    def session(self) -> "SessionManager":
        return self._session

    @property
    def pokemon(self) -> "Pokemon":
        return self._pokemon

    @property
    def sudoer(self) -> "Sudoer":
        return self._sudoer

    @property
    def trainer(self) -> "Trainer":
        return self._trainer

    @property
    def user(self) -> "User":
        return self._user
