from __future__ import annotations

from datetime import datetime
from typing import TypedDict

from pokedex.constants import CONSTANTS


class Currencies(TypedDict):
    coin: int

    @classmethod
    def default(cls) -> "Currencies":
        return cls(**{"coin": 0})


class TrainerDocument(TypedDict):
    user_id: int
    currencies: "Currencies"
    location: str
    created_at: "datetime"
    updated_at: "datetime"

    @classmethod
    def new_trainer(
        cls,
        user_id: int,
        currencies: "Currencies" = None,
    ) -> "TrainerDocument":
        if currencies is None:
            currencies = Currencies.default()
        return cls(
            **{
                "user_id": user_id,
                "currencies": currencies,
                "location": CONSTANTS.DEFAULT_LOCATION,
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
            }
        )
