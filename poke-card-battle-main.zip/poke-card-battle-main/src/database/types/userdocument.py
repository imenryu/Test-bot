from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, TypedDict


class UserDocument(TypedDict):
    user_id: int
    username: str | None
    is_bot: bool
    created_at: "datetime"
    updated_at: "datetime"

    @classmethod
    def new_user(
        cls,
        user_id: int,
        username: str | None,
        is_bot: bool,
    ) -> "TrainerDocument":
        return cls(
            **{
                "user_id": user_id,
                "username": username,
                "is_bot": is_bot,
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
            }
        )
