from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, TypedDict


class Privilege(TypedDict):
    can_gift_currency: bool
    can_gift_pokemon: bool
    can_gift_resource: bool
    can_organise_raid: bool
    can_modify_pokemon: bool
    can_modify_trainer: bool
    can_use_eval: bool

    @classmethod
    def default(cls) -> "Privilege":
        return cls(
            **{
                "can_gift_currency": False,
                "can_gift_pokemon": False,
                "can_gift_resource": False,
                "can_organise_raid": False,
                "can_modify_pokemon": False,
                "can_modify_trainer": False,
                "can_use_eval": False,
            }
        )

    @classmethod
    def grant_all(cls) -> "Privilege":
        return cls(
            **{
                "can_gift_currency": True,
                "can_gift_pokemon": True,
                "can_gift_resource": True,
                "can_organise_raid": True,
                "can_modify_pokemon": True,
                "can_modify_trainer": True,
                "can_use_eval": True,
            }
        )


class SudoerDocument(TypedDict):
    user_id: int
    privilege: "Privilege"
    created_at: "datetime"
    updated_at: "datetime"

    @classmethod
    def new_sudoer(
        cls,
        user_id: int,
        privilege: "Privilege" = None,
    ) -> "TrainerDocument":
        if privilege is None:
            privilege = Privilege.default()
        return cls(
            **{
                "user_id": user_id,
                "privilege": privilege,
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
            }
        )
