from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, TypedDict

if TYPE_CHECKING:
    from uuid import UUID


class PokemonDocument(TypedDict):
    uuid: UUID
    user_id: int
    dex_id: int
    shiny: bool
    nature: int
    ivs: dict[str, int]
    evs: dict[str, int]
    moveset: list[int]
    nickname: str | None
    favourite: bool
    created_at: datetime
    updated_at: datetime

    @classmethod
    def new_pokemon(
        cls,
        uuid: UUID,
        user_id: int,
        dex_id: int,
        shiny: bool,
        nature: int,
        ivs: dict[str, int],
        evs: dict[str, int],
        moveset: list[int],
    ) -> "TrainerDocument":
        return cls(
            **{
                "uuid": uuid,
                "user_id": user_id,
                "dex_id": dex_id,
                "shiny": shiny,
                "nature": nature,
                "ivs": ivs,
                "evs": evs,
                "moveset": moveset,
                "nickname": None,
                "favourite": False,
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
            }
        )
