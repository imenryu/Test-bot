from .database import Database

db = Database()

__all__ = ("db",)
