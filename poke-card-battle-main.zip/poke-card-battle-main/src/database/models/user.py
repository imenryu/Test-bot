from __future__ import annotations

import asyncio
from datetime import datetime
from typing import TYPE_CHECKING

from loguru import logger

from src.database.validators import UserValidator
from src.errors import DuplicateDocument, ErrorContext

if TYPE_CHECKING:
    from motor.motor_asyncio import (
        AsyncIOMotorClient,
        AsyncIOMotorCollection,
        AsyncIOMotorDatabase,
        ClientSession,
    )

    from src import enums
    from src.cache import UserSemaphore
    from src.database.types import UserDocument


class User:
    __slots__ = (
        "_client",
        "_database",
        "_collection",
        "_semaphore",
    )

    def __init__(
        self,
        client: AsyncIOMotorClient,
        database: AsyncIOMotorDatabase,
        semaphore: UserSemaphore,
    ) -> None:
        self._client: AsyncIOMotorClient = client
        self._database: AsyncIOMotorDatabase = database
        self._collection: AsyncIOMotorCollection = database[
            f"{self.__class__.__name__.lower()}s"
        ]
        self._semaphore: UserSemaphore = semaphore

    async def initialize(self) -> None:
        await self._indexes_check()
        logger.debug(f"{self.__class__.__name__} Initialized")

    async def shutdown(self) -> None:
        logger.debug(f"{self.__class__.__name__} Shutdown")

    def get_collection(self) -> AsyncIOMotorCollection:
        return self._collection

    async def _indexes_check(self) -> None:
        await asyncio.gather(
            self._collection.create_index("user_id", unique=True),
            self._collection.create_index("username"),
        )

    # -----------------------------
    # Public methods
    # -----------------------------
    async def is_user_exist(self, user_id: int = None, username: str = None) -> bool:
        if user_id is not None:
            valid_user_id = UserValidator.validate_user_id(user_id=user_id)
            query = {"user_id": valid_user_id}
        elif username is not None:
            valid_username = UserValidator.validate_username(username=username)
            query = {"username": valid_username}
        else:
            raise TypeError("Missing Argument: `user_id` or `username`")

        dbuser = await self._collection.find_one(query, projection={"_id": 1})
        return dbuser is not None

    async def get_user_by_id(self, user_id: int) -> UserDocument | None:
        valid_user_id = UserValidator.validate_user_id(user_id=user_id)

        if not await self.is_user_exist(user_id=valid_user_id):
            return None

        user = await self._collection.find_one({"user_id": valid_user_id})
        if user is not None:
            return UserValidator.validate_document(document=user)

        return None

    async def get_user_by_username(self, username: str) -> UserDocument | None:
        valid_username = UserValidator.validate_username(username=username)

        if not await self.is_user_exist(username=valid_username):
            return None

        user = await self._collection.find_one({"username": valid_username})
        if user is not None:
            return UserValidator.validate_document(document=user)

        return None

    async def add_user(
        self,
        document: UserDocument,
        session: ClientSession | None = None,
    ) -> bool:
        valid_document = UserValidator.validate_document(document=document)
        valid_user_id = valid_document["user_id"]

        if await self.get_user_by_id(user_id=valid_user_id):
            raise DuplicateDocument(
                message=f"User with user_id {valid_user_id} already exists.",
                context=ErrorContext(details={"document": valid_document}),
                user_friendly_message="This User already exists in your collection.",
            )

        dbsemaphore = self._semaphore.get(user_id=valid_user_id)
        async with dbsemaphore:
            await self._collection.insert_one(valid_document, session=session)

        return await self.is_user_exist(user_id=valid_user_id)

    async def update_user(
        self,
        user_id: int,
        username: str,
        session: ClientSession | None = None,
    ) -> bool:
        valid_user_id = UserValidator.validate_user_id(user_id=user_id)
        valid_username = UserValidator.validate_username(username=username)

        if await self.get_user_by_id(user_id=valid_user_id):
            return False

        updates = {
            "username": valid_username,
            "updated_at": datetime.utcnow(),
        }

        dbsemaphore = self._semaphore.get(user_id=valid_user_id)
        async with dbsemaphore:
            result = await self._collection.update_one(
                {"user_id": valid_user_id},
                {"$set": updates},
                session=session,
            )

        return result.modified_count > 0

    async def delete_user(
        self,
        user_id: int,
        session: ClientSession | None = None,
    ) -> bool:
        valid_user_id = UserValidator.validate_user_id(user_id=user_id)

        if not await self.get_user_by_id(user_id=valid_user_id):
            return False

        dbsemaphore = self._semaphore.get(user_id=valid_user_id)
        async with dbsemaphore:
            result = await self._collection.delete_one(
                {"user_id": valid_user_id}, session=session
            )

        return result.deleted_count > 0
