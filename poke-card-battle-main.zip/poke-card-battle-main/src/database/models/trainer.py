from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any

from loguru import logger

from src.database.validators import TrainerValidator
from src.errors import DuplicateDocument, ErrorContext

if TYPE_CHECKING:
    from motor.motor_asyncio import (
        AsyncIOMotorClient,
        AsyncIOMotorCollection,
        AsyncIOMotorDatabase,
        ClientSession,
    )

    from src import enums
    from src.cache import UserSemaphore
    from src.database.types import TrainerDocument


class Trainer:
    __slots__ = (
        "_client",
        "_database",
        "_collection",
        "_semaphore",
    )

    def __init__(
        self,
        client: AsyncIOMotorClient,
        database: AsyncIOMotorDatabase,
        semaphore: UserSemaphore,
    ) -> None:
        self._client: AsyncIOMotorClient = client
        self._database: AsyncIOMotorDatabase = database
        self._collection: AsyncIOMotorCollection = database[
            f"{self.__class__.__name__.lower()}s"
        ]
        self._semaphore: UserSemaphore = semaphore

    async def initialize(self) -> None:
        await self._indexes_check()
        logger.debug(f"{self.__class__.__name__} Initialized")

    async def shutdown(self) -> None:
        logger.debug(f"{self.__class__.__name__} Shutdown")

    def get_collection(self) -> AsyncIOMotorCollection:
        return self._collection

    async def _indexes_check(self) -> None:
        await self._collection.create_index("user_id", unique=True)

    # -----------------------------
    # Public methods
    # -----------------------------
    async def is_trainer_exist(self, user_id: int) -> bool:
        valid_user_id = TrainerValidator.validate_user_id(user_id=user_id)
        trainer = await self._collection.find_one(
            {"user_id": valid_user_id}, projection={"_id": 1}
        )
        return trainer is not None

    async def get_trainer(self, user_id: int) -> TrainerDocument | None:
        valid_user_id = TrainerValidator.validate_user_id(user_id=user_id)
        trainer = await self._collection.find_one({"user_id": valid_user_id})
        if trainer is not None:
            return TrainerValidator.validate_document(document=trainer)
        return None

    async def add_trainer(
        self,
        document: TrainerDocument,
        session: ClientSession | None = None,
    ) -> bool:
        valid_document = TrainerValidator.validate_document(document=document)
        valid_user_id = valid_document["user_id"]

        if await self.is_trainer_exist(user_id=valid_user_id):
            raise DuplicateDocument(
                message=f"Trainer with user_id {valid_user_id} already exists.",
                context=ErrorContext(details={"document": valid_document}),
                user_friendly_message="This Trainer already exists in your collection.",
            )

        dbsemaphore = self._semaphore.get(user_id=valid_user_id)
        async with dbsemaphore:
            await self._collection.insert_one(valid_document, session=session)
            return await self.is_trainer_exiat(user_id=valid_user_id)

    async def update_trainer(
        self,
        user_id: int,
        updates: dict[str, Any],
        session: ClientSession | None = None,
    ) -> bool:
        valid_user_id = TrainerValidator.validate_user_id(user_id=user_id)

        if not await self.is_trainer_exist(user_id=valid_user_id):
            return False

        updates["updated_at"] = datetime.utcnow()

        dbsemaphore = self._semaphore.get(user_id=valid_user_id)
        async with dbsemaphore:
            result = await self._collection.update_one(
                {"user_id": valid_user_id},
                {"$set": updates},
                session=session,
            )

        return result.modified_count > 0

    async def delete_user(
        self,
        user_id: int,
        session: ClientSession | None = None,
    ) -> bool:
        valid_user_id = TrainerValidator.validate_user_id(user_id=user_id)

        if not await self.is_trainer_exist(user_id=valid_user_id):
            return False

        dbsemaphore = self._semaphore.get(user_id=valid_user_id)
        async with dbsemaphore:
            result = await self._collection.delete_one(
                {"user_id": valid_user_id},
                session=session,
            )

        return result.deleted_count > 0
