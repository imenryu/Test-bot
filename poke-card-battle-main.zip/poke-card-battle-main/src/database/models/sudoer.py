from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from loguru import logger

from src.database.validators import SudoerValidator
from src.errors import DuplicateDocument, ErrorContext

if TYPE_CHECKING:
    from motor.motor_asyncio import (
        AsyncIOMotorClient,
        AsyncIOMotorCollection,
        AsyncIOMotorDatabase,
        ClientSession,
    )

    from src import enums
    from src.cache import UserSemaphore
    from src.database.types import Privilege, SudoerDocument


class Sudoer:
    """
    Sudoer Database
    """

    __slots__ = (
        "_client",
        "_database",
        "_collection",
        "_semaphore",
    )

    def __init__(
        self,
        client: AsyncIOMotorClient,
        database: AsyncIOMotorDatabase,
        semaphore: UserSemaphore,
    ) -> None:
        self._client: AsyncIOMotorClient = client
        self._database: AsyncIOMotorDatabase = database
        self._collection: AsyncIOMotorCollection = database[
            f"{self.__class__.__name__.lower()}s"
        ]
        self._semaphore: UserSemaphore = semaphore

    # ------------------------------------------------------------------
    # Initialization / Lifecycle
    # ------------------------------------------------------------------

    async def initialize(self) -> None:
        await self._indexes_check()
        logger.debug(f"{self.__class__.__name__} Initialized")

    async def shutdown(self) -> None:
        logger.debug(f"{self.__class__.__name__} Shutdown")

    def get_collection(self) -> AsyncIOMotorCollection:
        return self._collection

    async def _indexes_check(self) -> None:
        await self._collection.create_index("user_id", unique=True)

    # ------------------------------------------------------------------
    # Core Methods
    # ------------------------------------------------------------------

    async def is_user_sudo(
        self,
        user_id: int,
        privilege: enums.Privilege | None = None,
    ) -> bool:
        valid_user_id = SudoerValidator.validate_user_id(user_id=user_id)
        if not await self._collection.find_one(
            {"user_id": valid_user_id}, projection={"_id": 1}
        ):
            return False

        if privilege is not None:
            sudo = await self.get_sudo(user_id=valid_user_id)
            return sudo["privilege"][privilege.value]

        return True

    async def get_sudo(self, user_id: int) -> SudoerDocument | None:
        valid_user_id = SudoerValidator.validate_user_id(user_id=user_id)
        sudo = await self._collection.find_one({"user_id": valid_user_id})
        return SudoerValidator.validate_document(sudo) if sudo else None

    async def grant_sudo(
        self,
        document: SudoerDocument,
        session: ClientSession | None = None,
    ) -> bool:
        valid_document = SudoerValidator.validate_document(document=document)
        valid_user_id = valid_document["user_id"]

        if await self.is_user_sudo(user_id=valid_user_id):
            raise DuplicateDocument(
                message=f"Sudoer with user_id {valid_user_id} already exists.",
                context=ErrorContext(details={"document": valid_document}),
                user_friendly_message="This sudoer already exists in the system.",
            )

        dbsemaphore = self._semaphore.get(user_id=valid_user_id)
        async with dbsemaphore:
            await self._collection.insert_one(valid_document, session=session)

        return await self.is_user_sudo(user_id=valid_user_id)

    async def update_sudo_privilege(
        self,
        user_id: int,
        privilege: Privilege,
        session: ClientSession | None = None,
    ) -> bool:
        valid_user_id = SudoerValidator.validate_user_id(user_id=user_id)
        valid_privilege = SudoerValidator.validate_privilege(
            privilege=privilege)

        if not await self.is_user_sudo(user_id=valid_user_id):
            return False

        updates = {
            "privilege": valid_privilege,
            "updated_at": datetime.utcnow(),
        }

        dbsemaphore = self._semaphore.get(user_id=valid_user_id)
        async with dbsemaphore:
            result = await self._collection.update_one(
                {"user_id": valid_user_id}, {"$set": updates}, session=session
            )

        return result.modified_count > 0

    async def revoke_sudo(
        self,
        user_id: int,
        session: ClientSession | None = None,
    ) -> bool:
        valid_user_id = SudoerValidator.validate_user_id(user_id=user_id)

        if not await self.is_user_sudo(user_id=valid_user_id):
            return False

        dbsemaphore = self._semaphore.get(user_id=valid_user_id)
        async with dbsemaphore:
            result = await self._collection.delete_one(
                {"user_id": valid_user_id}, session=session
            )

        return result.deleted_count > 0
