from __future__ import annotations

import asyncio
from datetime import datetime
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from loguru import logger

from src.database.validators import PokemonValidator
from src.errors import DuplicateDocument, ErrorContext, UUIDGenerationFailed

if TYPE_CHECKING:
    from uuid import UUID

    from motor.motor_asyncio import (
        AsyncIOMotorClient,
        AsyncIOMotorCollection,
        AsyncIOMotorDatabase,
        ClientSession,
    )

    from src.cache import UserSemaphore
    from src.database.types import PokemonDocument


class Pokemon:
    """
    Pokémon database.
    """

    __slots__ = (
        "_client",
        "_database",
        "_collection",
        "_semaphore",
    )

    def __init__(
        self,
        client: AsyncIOMotorClient,
        database: AsyncIOMotorDatabase,
        semaphore: UserSemaphore,
    ) -> None:
        self._client: AsyncIOMotorClient = client
        self._database: AsyncIOMotorDatabase = database
        self._collection: AsyncIOMotorCollection = database[
            f"{self.__class__.__name__.lower()}s"
        ]
        self._semaphore: UserSemaphore = semaphore

    async def initialize(self) -> None:
        await self._indexes_check()
        logger.debug(f"{self.__class__.__name__} Initialized")

    async def shutdown(self) -> None:
        logger.debug(f"{self.__class__.__name__} Shutdown")

    def get_collection(self) -> AsyncIOMotorCollection:
        return self._collection

    async def _indexes_check(self) -> None:
        await asyncio.gather(
            self._collection.create_index("uuid", unique=True),
            self._collection.create_index("user_id"),
        )

    # ------------------------------------------------------------------
    # Public methods
    # ------------------------------------------------------------------
    async def generate_uuid(self) -> UUID:
        for _ in range(1000):
            candidate = uuid4()
            if not await self.is_pokemon_exist(uuid=candidate):
                return candidate

        raise UUIDGenerationFailed(
            message="UUID generation failed after 1000 attempts.",
            user_friendly_message="We couldn’t generate a unique Pokémon ID. Please try again later.",
        )

    async def is_pokemon_exist(self, uuid: str | UUID) -> bool:
        valid_uuid = PokemonValidator.validate_uuid(uuid=uuid)
        pokemon = await self._collection.find_one(
            {"uuid": valid_uuid}, projection={"_id": 1}
        )
        return pokemon is not None

    async def get_pokemon(self, uuid: str | UUID) -> PokemonDocument | None:
        valid_uuid = PokemonValidator.validate_uuid(uuid=uuid)
        pokemon = await self._collection.find_one({"uuid": valid_uuid})
        return PokemonValidator.validate_document(pokemon) if pokemon else None

    async def add_pokemon(
        self,
        document: PokemonDocument,
        session: ClientSession | None = None,
    ) -> bool:
        valid_doc = PokemonValidator.validate_document(document=document)
        valid_uuid, valid_user_id = valid_doc["uuid"], valid_doc["user_id"]

        if await self.is_pokemon_exist(uuid=valid_uuid):
            raise DuplicateDocument(
                message=f"Pokémon with UUID {valid_uuid} already exists.",
                context=ErrorContext(details={"document": valid_doc}),
                user_friendly_message="This Pokémon already exists in your collection.",
            )

        dbsemaphore = self._semaphore.get(user_id=valid_user_id)
        async with dbsemaphore:
            await self._collection.insert_one(valid_doc, session=session)

        return await self.is_pokemon_exist(uuid=valid_uuid)

    async def update_pokemon(
        self,
        user_id: int,
        uuid: str | UUID,
        updates: dict[str, Any],
        session: ClientSession | None = None,
    ) -> bool:
        valid_uuid = PokemonValidator.validate_uuid(uuid=uuid)
        valid_user_id = PokemonValidator.validate_user_id(user_id=user_id)

        if not await self.is_pokemon_exist(uuid=valid_uuid):
            return False

        updates["updated_at"] = datetime.utcnow()

        dbsemaphore = self._semaphore.get(user_id=valid_user_id)
        async with dbsemaphore:
            result = await self._collection.update_one(
                {"uuid": valid_uuid}, {"$set": updates}, session=session
            )

        return result.modified_count > 0

    async def delete_pokemon(
        self, user_id: int, uuid: str | UUID, session: ClientSession | None = None
    ) -> bool:
        valid_uuid = PokemonValidator.validate_uuid(uuid=uuid)
        valid_user_id = PokemonValidator.validate_user_id(user_id=user_id)

        if not await self.is_pokemon_exist(uuid=valid_uuid):
            return False

        dbsemaphore = self._semaphore.get(user_id=valid_user_id)
        async with dbsemaphore:
            result = await self._collection.delete_one(
                {"uuid": valid_uuid}, session=session
            )

        return result.deleted_count > 0
