from __future__ import annotations

from datetime import datetime

from src.database.types import UserDocument
from src.errors import (
    DocumentCorrupted,
    ErrorContext,
    InvalidDocumentFields,
)


class UserValidator:
    """Validation logic for User fields and complete User documents."""

    @staticmethod
    def validate_user_id(user_id: int) -> int:
        if isinstance(user_id, int) and user_id > 0:
            return user_id
        raise InvalidDocumentFields(
            message=(
                "User ID validation failed. Expected a positive integer greater than 0, "
                f"but received {user_id!r} of type {type(user_id).__name__}."
            ),
            context=ErrorContext(details={"user_id": user_id}),
            user_friendly_message="The user ID is invalid or corrupted.",
        )

    @staticmethod
    def validate_username(username: str | None) -> str | None:
        if username is None:
            return None

        if not isinstance(username, str):
            raise InvalidDocumentFields(
                message=f"Username validation failed. Expected a string, received {type(username).__name__}.",
                context=ErrorContext(details={"username": username}),
                user_friendly_message="The User's username is invalid.",
            )

        return username.lower().replace("@", "")

    @staticmethod
    def validate_is_bot(is_bot: bool) -> str:
        if not isinstance(is_bot, bool):
            raise InvalidDocumentFields(
                message=(
                    f"is_bot validation failed. Expected bool, got {type(is_bot).__name__}."
                ),
                context=ErrorContext(details={"is_bot": is_bot}),
                user_friendly_message="The User's is_bot is invalid or corrupted.",
            )

        return is_bot

    @staticmethod
    def validate_created_at(created_at: "datetime") -> "datetime":
        if not isinstance(created_at, datetime):
            raise InvalidDocumentFields(
                message=(
                    f"Created_at validation failed. Expected datetime, got {type(created_at).__name__}."
                ),
                context=ErrorContext(details={"created_at": created_at}),
                user_friendly_message="The User's creation timestamp is invalid or corrupted.",
            )
        return created_at

    @staticmethod
    def validate_updated_at(updated_at: "datetime") -> "datetime":
        if not isinstance(updated_at, datetime):
            raise InvalidDocumentFields(
                message=(
                    f"Updated_at validation failed. Expected datetime, got {type(updated_at).__name__}."
                ),
                context=ErrorContext(details={"updated_at": updated_at}),
                user_friendly_message="The User's update timestamp is invalid or corrupted.",
            )
        return updated_at

    @staticmethod
    def validate_document(document: "UserDocument") -> "UserDocument":
        if not isinstance(document, dict):
            raise InvalidDocumentFields(
                message=f"Expected UserDocument as dict, got {type(document).__name__}.",
                context=ErrorContext(
                    details={"document_type": type(document).__name__}
                ),
                user_friendly_message="The User record is invalid or corrupted.",
            )

        required_keys = {"user_id", "username",
                         "is_bot", "created_at", "updated_at"}
        missing_keys = required_keys - document.keys()
        if missing_keys:
            raise DocumentCorrupted(
                message=(
                    f"UserDocument validation failed. Missing keys: {missing_keys}. "
                    f"Provided keys: {list(document.keys())}."
                ),
                context=ErrorContext(
                    details={
                        "provided_keys": list(document.keys()),
                        "missing_keys": list(missing_keys),
                    }
                ),
                user_friendly_message="The User document structure is incomplete or corrupted.",
            )

        UserValidator.validate_user_id(document["user_id"])
        document["username"] = UserValidator.validate_username(
            document["username"])
        UserValidator.validate_is_bot(document["is_bot"])
        UserValidator.validate_created_at(document["created_at"])
        UserValidator.validate_updated_at(document["updated_at"])

        return UserDocument(**document)
