from __future__ import annotations

from datetime import datetime

from pokedex import pokedex
from src.database.types import Currencies, TrainerDocument
from src.errors import (
    DocumentCorrupted,
    ErrorContext,
    InvalidDocumentFields,
)


class TrainerValidator:
    """Validation logic for Trainer fields and complete Trainer documents."""

    @staticmethod
    def validate_user_id(user_id: int) -> int:
        if isinstance(user_id, int) and user_id > 0:
            return user_id
        raise InvalidDocumentFields(
            message=(
                "User ID validation failed. Expected a positive integer greater than 0, "
                f"but received {user_id!r} of type {type(user_id).__name__}."
            ),
            context=ErrorContext(details={"user_id": user_id}),
            user_friendly_message="The Trainer's user ID is invalid or corrupted.",
        )

    @staticmethod
    def validate_currencies(currencies: dict[str, int]) -> "Currencies":
        if not isinstance(currencies, dict):
            raise InvalidDocumentFields(
                message=f"Currencies validation failed. Expected a dict, received {type(currencies).__name__}.",
                context=ErrorContext(details={"currencies": currencies}),
                user_friendly_message="The Trainer's currencies data is invalid.",
            )

        required_keys = {
            "coin",
        }

        missing_keys = required_keys - currencies.keys()
        if missing_keys:
            raise DocumentCorrupted(
                message=(
                    f"currencies validation failed. Missing required keys: {missing_keys}. "
                    f"Provided keys: {list(currencies.keys())}."
                ),
                context=ErrorContext(
                    details={
                        "provided_keys": list(currencies.keys()),
                        "missing_keys": list(missing_keys),
                    }
                ),
                user_friendly_message="The Trainer's currencies data is incomplete or corrupted.",
            )

        for key, value in currencies.items():
            if isinstance(value, int) and value >= 0:
                continue
            raise InvalidDocumentFields(
                message=f"Currencies field {key!r} must be a positive integer. Received: {value!r}.",
                context=ErrorContext(details={key: value}),
                user_friendly_message=f"The Trainer's currency '{key}' has an invalid value.",
            )

        return Currencies(**currencies)

    @staticmethod
    def validate_location(location: str) -> str:
        if not isinstance(location, str):
            raise InvalidDocumentFields(
                message=(
                    f"location validation failed. Expected string, got {type(location).__name__}."
                ),
                context=ErrorContext(details={"location": location}),
                user_friendly_message="The Trainer's location is invalid or corrupted.",
            )
        if not any(location in value for _, value in pokedex.valid_locations.items()):
            raise InvalidDocumentFields(
                message=f"Invalid location '{location}'. Not found in Pokedex valid_locations list.",
                context=ErrorContext(details={"location": location}),
                user_friendly_message="The Trainer's current location is invalid or does not exist in the Pokémon world.",
            )

        return location

    @staticmethod
    def validate_created_at(created_at: "datetime") -> "datetime":
        if not isinstance(created_at, datetime):
            raise InvalidDocumentFields(
                message=(
                    f"Created_at validation failed. Expected datetime, got {type(created_at).__name__}."
                ),
                context=ErrorContext(details={"created_at": created_at}),
                user_friendly_message="The Trainer's creation timestamp is invalid or corrupted.",
            )
        return created_at

    @staticmethod
    def validate_updated_at(updated_at: "datetime") -> "datetime":
        if not isinstance(updated_at, datetime):
            raise InvalidDocumentFields(
                message=(
                    f"Updated_at validation failed. Expected datetime, got {type(updated_at).__name__}."
                ),
                context=ErrorContext(details={"updated_at": updated_at}),
                user_friendly_message="The Trainer's update timestamp is invalid or corrupted.",
            )
        return updated_at

    @staticmethod
    def validate_document(document: "TrainerDocument") -> "TrainerDocument":
        if not isinstance(document, dict):
            raise InvalidDocumentFields(
                message=f"Expected TrainerDocument as dict, got {type(document).__name__}.",
                context=ErrorContext(
                    details={"document_type": type(document).__name__}
                ),
                user_friendly_message="The Trainer record is invalid or corrupted.",
            )

        required_keys = {
            "user_id",
            "currencies",
            "location",
            "created_at",
            "updated_at",
        }
        missing_keys = required_keys - document.keys()
        if missing_keys:
            raise DocumentCorrupted(
                message=(
                    f"TrainerDocument validation failed. Missing keys: {missing_keys}. "
                    f"Provided keys: {list(document.keys())}."
                ),
                context=ErrorContext(
                    details={
                        "provided_keys": list(document.keys()),
                        "missing_keys": list(missing_keys),
                    }
                ),
                user_friendly_message="The Trainer document structure is incomplete or corrupted.",
            )

        TrainerValidator.validate_user_id(document["user_id"])
        document["currencies"] = TrainerValidator.validate_currencies(
            document["currencies"]
        )
        TrainerValidator.validate_location(document["location"])
        TrainerValidator.validate_created_at(document["created_at"])
        TrainerValidator.validate_updated_at(document["updated_at"])

        return TrainerDocument(**document)
