from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pokedex import pokedex
from pokedex.constants import CONSTANTS
from pokedex.utils import STATS_TEMPLATE
from src.database.types import PokemonDocument
from src.errors import (
    DocumentCorrupted,
    ErrorContext,
    InvalidDocumentFields,
    InvalidUUID,
)


class PokemonValidator:
    """Validation logic for Pokémon fields and complete Pokémon documents."""

    @staticmethod
    def validate_uuid(uuid: str | "UUID") -> "UUID":
        if isinstance(uuid, UUID):
            return uuid
        try:
            return UUID(str(uuid))
        except ValueError:
            raise InvalidUUID(
                message=(
                    "UUID validation failed. The provided value could not be parsed into a valid UUID. "
                    f"Received: {uuid!r}. Expected a standard UUID string or UUID object."
                ),
                context=ErrorContext(details={"uuid": uuid}),
                user_friendly_message="The Pokémon ID provided is not valid. Please try again with a correct ID.",
            )

    @staticmethod
    def validate_user_id(user_id: int) -> int:
        if isinstance(user_id, int) and user_id > 0:
            return user_id
        raise InvalidDocumentFields(
            message=(
                "User ID validation failed. Expected a positive integer greater than 0. "
                f"Received: {user_id!r} of type {type(user_id).__name__}."
            ),
            context=ErrorContext(details={"user_id": user_id}),
            user_friendly_message="Your account information appears to be invalid or corrupted.",
        )

    @staticmethod
    def validate_dex_id(dex_id: int) -> int:
        if isinstance(dex_id, int) and dex_id in pokedex.valid_pokemon_ids:
            return dex_id
        raise InvalidDocumentFields(
            message=(
                f"Dex ID validation failed. Value '{dex_id}' is not recognized as a valid Pokémon species. "
                f"Expected a valid species ID from the Pokédex."
            ),
            context=ErrorContext(details={"dex_id": dex_id}),
            user_friendly_message="The selected Pokémon species is invalid. Please choose a valid Pokémon.",
        )

    @staticmethod
    def validate_shiny(shiny: bool) -> bool:
        if isinstance(shiny, bool):
            return shiny
        raise InvalidDocumentFields(
            message=(
                "Shiny status validation failed. Expected a boolean value (True or False), "
                f"but received {shiny!r} of type {type(shiny).__name__}."
            ),
            context=ErrorContext(details={"shiny": shiny}),
            user_friendly_message="The shiny status for this Pokémon is invalid. Please try again.",
        )

    @staticmethod
    def validate_nature(nature: int) -> int:
        if (
            isinstance(nature, int)
            and CONSTANTS.MIN_NATURE_ID <= nature <= CONSTANTS.MAX_NATURE_ID
        ):
            return nature
        raise InvalidDocumentFields(
            message=(
                f"Nature validation failed. Expected an integer between {CONSTANTS.MIN_NATURE_ID} "
                f"and {CONSTANTS.MAX_NATURE_ID}, but received {nature!r}."
            ),
            context=ErrorContext(details={"nature": nature}),
            user_friendly_message="The Pokémon's nature is invalid. Please select a valid nature.",
        )

    @staticmethod
    def validate_ivs(stats: dict[str, int]) -> dict[str, int]:
        if not isinstance(stats, dict):
            raise InvalidDocumentFields(
                message=(
                    "IVs validation failed. Expected a dictionary with stat names as keys and integers as values. "
                    f"Received: {stats!r} of type {type(stats).__name__}."
                ),
                context=ErrorContext(details={"ivs": stats}),
                user_friendly_message="The Pokémon's IV data is invalid or corrupted.",
            )
        for key, value in stats.items():
            if not isinstance(key, str):
                raise InvalidDocumentFields(
                    message=f"IV stat key validation failed. Expected a string, but got {type(key).__name__}.",
                    context=ErrorContext(
                        details={"invalid_key": key, "ivs": stats}),
                    user_friendly_message="One of the IV stat keys is invalid.",
                )
            if key not in STATS_TEMPLATE:
                raise InvalidDocumentFields(
                    message=(
                        f"IV stat key validation failed. '{key}' is not a recognized Pokémon stat. "
                        f"Expected one of {list(STATS_TEMPLATE.keys())}."
                    ),
                    context=ErrorContext(
                        details={"invalid_key": key, "ivs": stats}),
                    user_friendly_message=f"'{key}' is not a valid Pokémon stat for IVs.",
                )
            if not isinstance(value, int):
                raise InvalidDocumentFields(
                    message=(
                        f"IV stat value for '{key}' must be an integer, but received {value!r} "
                        f"of type {type(value).__name__}."
                    ),
                    context=ErrorContext(
                        details={"invalid_value": value, "ivs": stats}
                    ),
                    user_friendly_message=f"The IV value for '{key}' is invalid.",
                )
            if not CONSTANTS.MIN_IV_PER_STAT <= value <= CONSTANTS.MAX_IV_PER_STAT:
                raise InvalidDocumentFields(
                    message=(
                        f"IV stat value for '{key}' is out of range. "
                        f"Received: {value}, expected a value between "
                        f"{CONSTANTS.MIN_IV_PER_STAT} and {CONSTANTS.MAX_IV_PER_STAT}."
                    ),
                    context=ErrorContext(
                        details={"invalid_value": value, "ivs": stats}
                    ),
                    user_friendly_message=(
                        f"IV value for '{key}' must be between "
                        f"{CONSTANTS.MIN_IV_PER_STAT} and {CONSTANTS.MAX_IV_PER_STAT}."
                    ),
                )
        return stats

    @staticmethod
    def validate_evs(stats: dict[str, int]) -> dict[str, int]:
        if not isinstance(stats, dict):
            raise InvalidDocumentFields(
                message=(
                    "EVs validation failed. Expected a dictionary with stat names as keys and integers as values. "
                    f"Received: {stats!r} of type {type(stats).__name__}."
                ),
                context=ErrorContext(details={"evs": stats}),
                user_friendly_message="The Pokémon's EV data is invalid or corrupted.",
            )
        for key, value in stats.items():
            if not isinstance(key, str):
                raise InvalidDocumentFields(
                    message=f"EV stat key validation failed. Expected a string, but got {type(key).__name__}.",
                    context=ErrorContext(
                        details={"invalid_key": key, "evs": stats}),
                    user_friendly_message="One of the EV stat keys is invalid.",
                )
            if key not in STATS_TEMPLATE:
                raise InvalidDocumentFields(
                    message=(
                        f"EV stat key validation failed. '{key}' is not a recognized Pokémon stat. "
                        f"Expected one of {list(STATS_TEMPLATE.keys())}."
                    ),
                    context=ErrorContext(
                        details={"invalid_key": key, "evs": stats}),
                    user_friendly_message=f"'{key}' is not a valid Pokémon stat for EVs.",
                )
            if not isinstance(value, int):
                raise InvalidDocumentFields(
                    message=(
                        f"EV stat value for '{key}' must be an integer, but received {value!r} "
                        f"of type {type(value).__name__}."
                    ),
                    context=ErrorContext(
                        details={"invalid_value": value, "evs": stats}
                    ),
                    user_friendly_message=f"The EV value for '{key}' is invalid.",
                )
            if not CONSTANTS.MIN_EV_PER_STAT <= value <= CONSTANTS.MAX_EV_PER_STAT:
                raise InvalidDocumentFields(
                    message=(
                        f"EV stat value for '{key}' is out of range. "
                        f"Received: {value}, expected a value between "
                        f"{CONSTANTS.MIN_EV_PER_STAT} and {CONSTANTS.MAX_EV_PER_STAT}."
                    ),
                    context=ErrorContext(
                        details={"invalid_value": value, "evs": stats}
                    ),
                    user_friendly_message=(
                        f"EV value for '{key}' must be between "
                        f"{CONSTANTS.MIN_EV_PER_STAT} and {CONSTANTS.MAX_EV_PER_STAT}."
                    ),
                )
        return stats

    @staticmethod
    def validate_moveset(moveset: list[int]) -> list[int]:
        if not isinstance(moveset, list):
            raise InvalidDocumentFields(
                message=(
                    "Moveset validation failed. Expected a list of integers representing move IDs, "
                    f"but received {moveset!r} of type {type(moveset).__name__}."
                ),
                context=ErrorContext(details={"moveset": moveset}),
                user_friendly_message="The Pokémon's moveset data is invalid.",
            )
        for move in moveset:
            if not isinstance(move, int):
                raise InvalidDocumentFields(
                    message=(
                        "Move ID validation failed. Each move must be an integer, "
                        f"but received {move!r} of type {type(move).__name__}."
                    ),
                    context=ErrorContext(
                        details={"invalid_move": move, "moveset": moveset}
                    ),
                    user_friendly_message=f"The move '{move}' is invalid. Moves must be valid IDs.",
                )
            if move not in pokedex.valid_move_ids:
                raise InvalidDocumentFields(
                    message=(
                        f"Move ID validation failed. '{move}' is not a recognized move. "
                        f"Expected a valid move ID from the Pokédex."
                    ),
                    context=ErrorContext(
                        details={"invalid_move": move, "moveset": moveset}
                    ),
                    user_friendly_message=f"The move ID '{move}' is not recognized. Please select a valid Pokémon move.",
                )
        return moveset

    @staticmethod
    def validate_nickname(nickname: str | None) -> str | None:
        if nickname is None:
            return None
        if not isinstance(nickname, str):
            raise InvalidDocumentFields(
                message=(
                    "Nickname validation failed. Expected a string, "
                    f"but received {nickname!r} of type {type(nickname).__name__}."
                ),
                context=ErrorContext(details={"nickname": nickname}),
                user_friendly_message="The Pokémon's nickname is invalid.",
            )
        if not 0 > len(str) > 10:
            raise InvalidDocumentFields(
                message=(
                    "Nickname validation failed. length out of range, "
                    f"expected 0-10 length, but recieved {len(nickname)}."
                ),
                context=ErrorContext(details={"nickname": nickname}),
                user_friendly_message="The Pokémon's nickname length out of range.",
            )
        return nickname

    @staticmethod
    def validate_favourite(favourite: bool) -> bool:
        if isinstance(favourite, bool):
            return favourite
        raise InvalidDocumentFields(
            message=(
                "Favourite validation failed. expected a bool, "
                f"but recieved {favourite!r} of type {type(favourite).__name__}."
            ),
            context=ErrorContext(details={"favourite": favourite}),
            user_friendly_message="The Pokémon's favourite is invalid.",
        )

    @staticmethod
    def validate_created_at(created_at: "datetime") -> "datetime":
        if not isinstance(created_at, datetime):
            raise InvalidDocumentFields(
                message=(
                    f"Created_at validation failed. Expected a datetime object, "
                    f"but received {created_at!r} of type {type(created_at).__name__}."
                ),
                context=ErrorContext(details={"created_at": created_at}),
                user_friendly_message="The Pokémon's creation timestamp is invalid or corrupted.",
            )
        return created_at

    @staticmethod
    def validate_updated_at(updated_at: "datetime") -> "datetime":
        if not isinstance(updated_at, datetime):
            raise InvalidDocumentFields(
                message=(
                    f"Updated_at validation failed. Expected a datetime object, "
                    f"but received {updated_at!r} of type {type(updated_at).__name__}."
                ),
                context=ErrorContext(details={"updated_at": updated_at}),
                user_friendly_message="The Pokémon's update timestamp is invalid or corrupted.",
            )
        return updated_at

    @staticmethod
    def validate_document(document: "PokemonDocument") -> "PokemonDocument":
        if not isinstance(document, dict):
            raise InvalidDocumentFields(
                message=f"Expected PokemonDocument as dict, got {type(document).__name__}.",
                context=ErrorContext(
                    details={"document_type": type(document).__name__}
                ),
                user_friendly_message="The Pokemon record is invalid or corrupted.",
            )

        required_keys = {
            "uuid",
            "user_id",
            "dex_id",
            "shiny",
            "nature",
            "ivs",
            "evs",
            "moveset",
            "created_at",
            "updated_at",
        }

        missing_keys = required_keys - document.keys()
        if missing_keys:
            raise DocumentCorrupted(
                message=(
                    "Document structure validation failed. Missing required keys. "
                    f"Missing: {missing_keys}. Provided keys: {list(document.keys())}."
                ),
                context=ErrorContext(
                    details={
                        "document_keys": list(document.keys()),
                        "missing_keys": list(missing_keys),
                    }
                ),
                user_friendly_message="The Pokémon data is incomplete or corrupted.",
            )

        PokemonValidator.validate_uuid(document["uuid"])
        PokemonValidator.validate_user_id(document["user_id"])
        PokemonValidator.validate_dex_id(document["dex_id"])
        PokemonValidator.validate_shiny(document["shiny"])
        PokemonValidator.validate_nature(document["nature"])
        PokemonValidator.validate_ivs(document["ivs"])
        PokemonValidator.validate_evs(document["evs"])
        PokemonValidator.validate_moveset(document["moveset"])
        PokemonValidator.validate_nickname(document["nickname"])
        PokemonValidator.validate_favourite(document["favourite"])
        PokemonValidator.validate_created_at(document["created_at"])
        PokemonValidator.validate_updated_at(document["updated_at"])

        return PokemonDocument(**document)
