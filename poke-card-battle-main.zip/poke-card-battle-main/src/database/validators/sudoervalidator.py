from __future__ import annotations

from datetime import datetime

from src.database.types import Privilege, SudoerDocument
from src.errors import (
    DocumentCorrupted,
    ErrorContext,
    InvalidDocumentFields,
)


class SudoerValidator:
    """Validation logic for Sudoer fields and complete Sudoer documents."""

    @staticmethod
    def validate_user_id(user_id: int) -> int:
        if isinstance(user_id, int) and user_id > 0:
            return user_id
        raise InvalidDocumentFields(
            message=(
                "User ID validation failed. Expected a positive integer greater than 0, "
                f"but received {user_id!r} of type {type(user_id).__name__}."
            ),
            context=ErrorContext(details={"user_id": user_id}),
            user_friendly_message="The Sudoer's user ID is invalid or corrupted.",
        )

    @staticmethod
    def validate_privilege(privilege: dict[str, bool]) -> "Privilege":
        if not isinstance(privilege, dict):
            raise InvalidDocumentFields(
                message=f"Privilege validation failed. Expected a dict, received {type(privilege).__name__}.",
                context=ErrorContext(details={"privilege": privilege}),
                user_friendly_message="The Sudoer's privilege data is invalid.",
            )

        required_keys = {
            "can_gift_currency",
            "can_gift_pokemon",
            "can_gift_resource",
            "can_organise_raid",
            "can_modify_pokemon",
            "can_modify_trainer",
            "can_use_eval",
        }

        missing_keys = required_keys - privilege.keys()
        if missing_keys:
            raise DocumentCorrupted(
                message=(
                    f"Privilege validation failed. Missing required keys: {missing_keys}. "
                    f"Provided keys: {list(privilege.keys())}."
                ),
                context=ErrorContext(
                    details={
                        "provided_keys": list(privilege.keys()),
                        "missing_keys": list(missing_keys),
                    }
                ),
                user_friendly_message="The Sudoer's privilege structure is incomplete or corrupted.",
            )

        for key, value in privilege.items():
            if key not in required_keys or not isinstance(value, bool):
                raise InvalidDocumentFields(
                    message=f"Privilege field {key!r} must be a boolean. Received: {value!r}.",
                    context=ErrorContext(details={key: value}),
                    user_friendly_message=f"The Sudoer's privilege '{key}' has an invalid value.",
                )

        return Privilege(**privilege)

    @staticmethod
    def validate_created_at(created_at: "datetime") -> "datetime":
        if not isinstance(created_at, datetime):
            raise InvalidDocumentFields(
                message=(
                    f"Created_at validation failed. Expected datetime, got {type(created_at).__name__}."
                ),
                context=ErrorContext(details={"created_at": created_at}),
                user_friendly_message="The Sudoer's creation timestamp is invalid or corrupted.",
            )
        return created_at

    @staticmethod
    def validate_updated_at(updated_at: "datetime") -> "datetime":
        if not isinstance(updated_at, datetime):
            raise InvalidDocumentFields(
                message=(
                    f"Updated_at validation failed. Expected datetime, got {type(updated_at).__name__}."
                ),
                context=ErrorContext(details={"updated_at": updated_at}),
                user_friendly_message="The Sudoer's update timestamp is invalid or corrupted.",
            )
        return updated_at

    @staticmethod
    def validate_document(document: "SudoerDocument") -> "SudoerDocument":
        if not isinstance(document, dict):
            raise InvalidDocumentFields(
                message=f"Expected SudoerDocument as dict, got {type(document).__name__}.",
                context=ErrorContext(
                    details={"document_type": type(document).__name__}
                ),
                user_friendly_message="The Sudoer record is invalid or corrupted.",
            )

        required_keys = {"user_id", "privilege", "created_at", "updated_at"}
        missing_keys = required_keys - document.keys()
        if missing_keys:
            raise DocumentCorrupted(
                message=(
                    f"SudoerDocument validation failed. Missing keys: {missing_keys}. "
                    f"Provided keys: {list(document.keys())}."
                ),
                context=ErrorContext(
                    details={
                        "provided_keys": list(document.keys()),
                        "missing_keys": list(missing_keys),
                    }
                ),
                user_friendly_message="The Sudoer document structure is incomplete or corrupted.",
            )

        SudoerValidator.validate_user_id(document["user_id"])
        document["privilege"] = SudoerValidator.validate_privilege(
            document["privilege"]
        )
        SudoerValidator.validate_created_at(document["created_at"])
        SudoerValidator.validate_updated_at(document["updated_at"])

        return SudoerDocument(**document)
